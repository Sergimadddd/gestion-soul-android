package com.soulmiguelturra.gestionsoul

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.compose.setContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBars
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Divider
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.launch
import java.text.DecimalFormat
import java.time.Instant
import java.util.UUID

private val SoulBackground = Color(0xFF030712)
private val SoulPanel = Color(0xFF111827)
private val SoulPanel2 = Color(0xFF18181B)
private val SoulBorder = Color(0xFF374151)
private val SoulAmber = Color(0xFFFBBF24)
private val SoulAmberSoft = Color(0xFFFCD34D)
private val SoulText = Color(0xFFF3F4F6)
private val SoulMuted = Color(0xFF9CA3AF)
private val SoulGreen = Color(0xFF34D399)
private val SoulRed = Color(0xFFFB7185)
private val money = DecimalFormat("0.00")

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = android.graphics.Color.rgb(3,7,18)
        window.navigationBarColor = android.graphics.Color.rgb(3,7,18)
        setContent { SoulTheme { GestionSoulApp() } }
    }
}

@Composable
fun SoulTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = androidx.compose.material3.darkColorScheme(
            primary = SoulAmber,
            onPrimary = Color.Black,
            background = SoulBackground,
            surface = SoulPanel,
            onSurface = SoulText,
            onBackground = SoulText,
            error = SoulRed
        ),
        typography = androidx.compose.material3.Typography(
            headlineLarge = androidx.compose.ui.text.TextStyle(fontWeight = FontWeight.Black, fontSize = 30.sp),
            headlineMedium = androidx.compose.ui.text.TextStyle(fontWeight = FontWeight.Black, fontSize = 23.sp),
            titleLarge = androidx.compose.ui.text.TextStyle(fontWeight = FontWeight.Bold, fontSize = 20.sp)
        ),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GestionSoulApp(vm: MainViewModel = viewModel()) {
    val context = LocalContext.current
    val products by vm.products.collectAsState()
    val recipes by vm.recipes.collectAsState()
    val suppliers by vm.suppliers.collectAsState()
    val categories by vm.categories.collectAsState()
    val recipeCategories by vm.recipeCategories.collectAsState()
    val supplierCategories by vm.supplierCategories.collectAsState()
    val fixedCosts by vm.fixedCosts.collectAsState()
    val sales by vm.sales.collectAsState()
    val objectives by vm.objectives.collectAsState()
    val posts by vm.posts.collectAsState()
    val brandManual by vm.brandManual.collectAsState()
    val businessAnalysis by vm.businessAnalysis.collectAsState()
    val marketingStrategy by vm.marketingStrategy.collectAsState()
    val busy by vm.busy.collectAsState()
    val message by vm.message.collectAsState()
    val search by vm.search.collectAsState()
    val recipeSearch by vm.recipeSearch.collectAsState()
    val invoiceItems by vm.invoiceItems.collectAsState()

    var openSection by rememberSaveable { mutableStateOf<String?>(null) }
    var productDialog by remember { mutableStateOf<Product?>(null) }
    var showProductForm by rememberSaveable { mutableStateOf(false) }
    var recipeDialog by remember { mutableStateOf<Recipe?>(null) }
    var showRecipeForm by rememberSaveable { mutableStateOf(false) }
    var supplierDialog by remember { mutableStateOf<Supplier?>(null) }
    var showSupplierForm by rememberSaveable { mutableStateOf(false) }
    var showOrder by rememberSaveable { mutableStateOf(false) }
    var showDashboard by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var showCosts by rememberSaveable { mutableStateOf(false) }
    var showObjectives by rememberSaveable { mutableStateOf(false) }
    var showProductCatalog by rememberSaveable { mutableStateOf(false) }
    var selectedProductCategory by remember { mutableStateOf<Category?>(null) }
    var manageProductCategories by rememberSaveable { mutableStateOf(false) }
    var showRecipeCatalog by rememberSaveable { mutableStateOf(false) }
    var selectedRecipeCategory by remember { mutableStateOf<Category?>(null) }
    var manageRecipeCategories by rememberSaveable { mutableStateOf(false) }
    var showInvoiceText by remember { mutableStateOf<String?>(null) }
    var showInvoiceReview by rememberSaveable { mutableStateOf(false) }
    var showRecipeUploadText by remember { mutableStateOf<String?>(null) }
    var confirmDeleteProduct by remember { mutableStateOf<Product?>(null) }
    var confirmDeleteRecipe by remember { mutableStateOf<Recipe?>(null) }
    var confirmDeleteSupplier by remember { mutableStateOf<Supplier?>(null) }
    var confirmDeleteObjective by remember { mutableStateOf<MarketingObjective?>(null) }

    val snackbarHostState = remember { SnackbarHostState() }
    val uiScope = rememberCoroutineScope()
    LaunchedEffect(message) {
        message?.let { snackbarHostState.showSnackbar(it); vm.clearMessage() }
    }
    LaunchedEffect(invoiceItems.size) {
        if (invoiceItems.isNotEmpty()) showInvoiceReview = true
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        val bitmap = loadBitmap(context, uri)
        if (bitmap != null) {
            uiScope.launch {
                try {
                    val ocr=vm.ocr(bitmap)
                    showInvoiceText=ocr
                } catch (e:Exception) { showInvoiceText="No se pudo realizar OCR: ${e.message}" }
            }
        }
    }
    val cameraLauncher = rememberLauncherForActivityResult(ActivityResultContracts.TakePicturePreview()) { bitmap: Bitmap? ->
        if (bitmap != null) {
            uiScope.launch {
                try { showInvoiceText=vm.ocr(bitmap) } catch (e:Exception) { showInvoiceText="No se pudo realizar OCR: ${e.message}" }
            }
        }
    }
    val cameraPermissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) cameraLauncher.launch(null) else showInvoiceText = "Necesito permiso de cámara para fotografiar una factura."
    }
    val invoiceFilePicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        uiScope.launch {
            try {
                val name=context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use{c->if(c.moveToFirst())c.getString(0)else"factura"} ?: "factura"
                val bytes=context.contentResolver.openInputStream(uri)?.use{it.readBytes()} ?: ByteArray(0)
                val lower=name.lowercase()
                val extracted=if(lower.endsWith(".pdf")) PdfOcrService.extractText(context,bytes) else DocumentTextExtractor.fromBytes(name,bytes)
                showInvoiceText=extracted.take(30000)
            } catch(e:Exception){showInvoiceText="No se pudo leer la factura: ${e.message}"}
        }
    }

    val documentPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        try {
            val name=context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use{c->if(c.moveToFirst())c.getString(0)else"documento"} ?: "documento"
            val bytes=context.contentResolver.openInputStream(uri)?.use{it.readBytes()} ?: ByteArray(0)
            showRecipeUploadText="Archivo: $name\n\n${DocumentTextExtractor.fromBytes(name,bytes).take(20000)}"
        } catch(e:Exception){showRecipeUploadText="No se pudo leer el documento: ${e.message}"}
    }
    val salesPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        try {
            val name=context.contentResolver.query(uri, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)?.use{c->if(c.moveToFirst())c.getString(0)else"ventas.csv"} ?: "ventas.csv"
            val bytes=context.contentResolver.openInputStream(uri)?.use{it.readBytes()} ?: ByteArray(0)
            val text=DocumentTextExtractor.fromBytes(name,bytes); vm.saveSalesFromCsv(text)
        } catch(e:Exception){vm.clearMessage()}
    }
    val backupCreate = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        try{context.contentResolver.openOutputStream(uri)?.use{it.write(vm.exportBackup().toByteArray())};}catch(_:Exception){}
    }
    val backupOpen = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        try{val text=context.contentResolver.openInputStream(uri)?.use{it.readBytes()?.toString(Charsets.UTF_8)}?: "";vm.importBackup(text)}catch(_:Exception){}
    }
    val brandPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        uri ?: return@rememberLauncherForActivityResult
        try{val name=context.contentResolver.query(uri,arrayOf(android.provider.OpenableColumns.DISPLAY_NAME),null,null,null)?.use{c->if(c.moveToFirst())c.getString(0)else"manual"}?:"manual";val bytes=context.contentResolver.openInputStream(uri)?.use{it.readBytes()}?:ByteArray(0);vm.saveBrandFromText(name,DocumentTextExtractor.fromBytes(name,bytes))}catch(_:Exception){}
    }

    Scaffold(
        containerColor = SoulBackground,
        snackbarHost = { SnackbarHost(snackbarHostState) },
        contentWindowInsets = WindowInsets.navigationBars
    ) { padding ->
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF111827),SoulBackground))).padding(padding)) {
            LazyColumn(
                modifier=Modifier.fillMaxSize().safeDrawingPadding().padding(horizontal=14.dp),
                verticalArrangement=Arrangement.spacedBy(10.dp)
            ) {
                item { SoulHeader(onSettings={showSettings=true}) }

                item {
                    MainSection(
                        id="products", title="1. Productos", badge=products.size, openSection=openSection,
                        onToggle={openSection=if(openSection=="products")null else"products"}
                    ) {
                        ProductSection(
                            products=products, categories=categories, search=search,
                            onSearch=vm::setSearch,
                            onAdd={productDialog=null;showProductForm=true},
                            onCamera={
                                if(ContextCompat.checkSelfPermission(context,Manifest.permission.CAMERA)==PackageManager.PERMISSION_GRANTED) cameraLauncher.launch(null)
                                else cameraPermissionLauncher.launch(Manifest.permission.CAMERA)
                            },
                            onGallery={imagePicker.launch("image/*")},
                            onFile={invoiceFilePicker.launch(arrayOf("text/plain","text/csv","application/pdf","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))},
                            onCatalog={showProductCatalog=true},
                            onEdit={productDialog=it}, onDelete={confirmDeleteProduct=it}
                        )
                    }
                }

                item {
                    MainSection("recipes","2. Recetas",recipes.size,openSection,{openSection=if(openSection=="recipes")null else"recipes"}) {
                        RecipeSection(recipes,recipeCategories,recipeSearch,vm::setRecipeSearch,onAdd={recipeDialog=null;showRecipeForm=true},onEdit={recipeDialog=it},onDelete={confirmDeleteRecipe=it},onImport={showRecipeUploadText=null;documentPicker.launch(arrayOf("image/*","application/pdf","text/plain","text/csv","application/vnd.openxmlformats-officedocument.wordprocessingml.document","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))},onCatalog={showRecipeCatalog=true})
                    }
                }

                item {
                    MainSection("suppliers","3. Proveedores y Pedidos",suppliers.size,openSection,{openSection=if(openSection=="suppliers")null else"suppliers"}) {
                        SupplierSection(suppliers,onManage={supplierDialog=it},onAdd={supplierDialog=null;showSupplierForm=true},onDelete={confirmDeleteSupplier=it},onOrder={showOrder=true})
                    }
                }

                item {
                    MainSection("analysis","4. Análisis",0,openSection,{openSection=if(openSection=="analysis")null else"analysis"}) {
                        AnalysisUi(vm, products, recipes, fixedCosts, businessAnalysis, showCosts={showCosts=true}, showDashboard={showDashboard=true}, runAnalysis=vm::runBusinessAnalysis, busy=busy)
                    }
                }

                item {
                    MainSection("marketing","5. Marketing y Estrategia",0,openSection,{openSection=if(openSection=="marketing")null else"marketing"}) {
                        MarketingUi(vm, sales, objectives, marketingStrategy, showObjectives={showObjectives=true}, onImportSales={salesPicker.launch(arrayOf("text/*","application/csv","application/vnd.ms-excel","application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"))}, busy=busy)
                    }
                }

                item {
                    MainSection("community","6. Community Manager AI",0,openSection,{openSection=if(openSection=="community")null else"community"}) {
                        CommunityUi(vm, brandManual, objectives, posts, onBrandImport={brandPicker.launch(arrayOf("text/plain","text/markdown","application/pdf","application/vnd.openxmlformats-officedocument.wordprocessingml.document"))},busy=busy)
                    }
                }
                item { Spacer(Modifier.height(120.dp)) }
            }

            if (busy) {
                Surface(color=Color.Black.copy(alpha=.6f), modifier=Modifier.fillMaxSize()) { Box(Modifier.fillMaxSize(),contentAlignment=Alignment.Center){Card(colors=CardDefaults.cardColors(containerColor=SoulPanel2),shape=RoundedCornerShape(20.dp)){Column(horizontalAlignment=Alignment.CenterHorizontally,modifier=Modifier.padding(24.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){CircularProgressIndicator(color=SoulAmber);Text("Procesando...",color=SoulText,fontWeight=FontWeight.Bold)}}} }
            }
        }
    }

    if(showProductCatalog){
        CatalogDialog("Catálogo de Productos",categories,products.map{it.category},onDismiss={showProductCatalog=false},onManage={manageProductCategories=true},onSelect={selectedProductCategory=it})
    }
    if(selectedProductCategory!=null){
        CategoryItemsDialog("Productos · ${selectedProductCategory!!.name}",products.filter{ParsingUtils.normalize(it.category)==ParsingUtils.normalize(selectedProductCategory!!.name)},onDismiss={selectedProductCategory=null},onEdit={item->if(item is Product){productDialog=item;selectedProductCategory=null}},onDelete={item->if(item is Product){confirmDeleteProduct=item;selectedProductCategory=null}})
    }
    if(manageProductCategories){
        ManageCategoriesDialog("Modificar Categorías de Productos",categories,onAdd={vm.addCategory("product",it)},onRename={c,n->vm.renameCategory(c,"product",n)},onDelete={vm.deleteCategory(it,"product")},onDismiss={manageProductCategories=false})
    }
    if(showRecipeCatalog){
        CatalogDialog("Catálogo de Recetas",recipeCategories,recipes.map{it.category},onDismiss={showRecipeCatalog=false},onManage={manageRecipeCategories=true},onSelect={selectedRecipeCategory=it})
    }
    if(selectedRecipeCategory!=null){
        CategoryItemsDialog("Recetas · ${selectedRecipeCategory!!.name}",recipes.filter{ParsingUtils.normalize(it.category)==ParsingUtils.normalize(selectedRecipeCategory!!.name)},onDismiss={selectedRecipeCategory=null},onEdit={item->if(item is Recipe){recipeDialog=item;selectedRecipeCategory=null}},onDelete={item->if(item is Recipe){confirmDeleteRecipe=item;selectedRecipeCategory=null}})
    }
    if(manageRecipeCategories){
        ManageCategoriesDialog("Modificar Categorías de Recetas",recipeCategories,onAdd={vm.addCategory("recipe",it)},onRename={c,n->vm.renameCategory(c,"recipe",n)},onDelete={vm.deleteCategory(it,"recipe")},onDismiss={manageRecipeCategories=false})
    }

    if(showProductForm || productDialog!=null){ProductDialog(productDialog,categories,suppliers,supplierCategories,onDismiss={productDialog=null;showProductForm=false},onSave={p,d,c,s,sc,cost,dis,vat,serv,pvp->vm.saveProduct(p,d,c,s,sc,cost,dis,vat,serv,pvp);productDialog=null;showProductForm=false})}
    if(confirmDeleteProduct!=null){ConfirmDialog("Eliminar Producto","¿Seguro que quieres eliminar «${confirmDeleteProduct!!.description}»?",{confirmDeleteProduct=null},{vm.deleteProduct(confirmDeleteProduct!!.id);confirmDeleteProduct=null})}
    if(showRecipeForm || recipeDialog!=null){RecipeDialog(recipeDialog,recipeCategories,categories,products,onDismiss={recipeDialog=null;showRecipeForm=false},onGenerateSalesSuggestion={name,category,totalCost,pvp->vm.generateSalesSuggestion(name,category,totalCost,pvp)},onSave={r,d,pv,cat,type,prods,fixed,groups,sel,suggestion->vm.saveRecipe(r,d,pv,cat,type,prods,fixed,groups,sel,suggestion);recipeDialog=null;showRecipeForm=false})}
    if(confirmDeleteRecipe!=null){ConfirmDialog("Eliminar Receta","¿Seguro que quieres eliminar «${confirmDeleteRecipe!!.description}»?",{confirmDeleteRecipe=null},{vm.deleteRecipe(confirmDeleteRecipe!!.id);confirmDeleteRecipe=null})}
    if(showSupplierForm || supplierDialog!=null){SupplierDialog(supplierDialog,onDismiss={supplierDialog=null;showSupplierForm=false},onSave={s,n,d,ph->vm.saveSupplier(s,n,d,ph);supplierDialog=null;showSupplierForm=false})}
    if(confirmDeleteSupplier!=null){ConfirmDialog("Eliminar Proveedor","¿Seguro que quieres eliminar «${confirmDeleteSupplier!!.name}»?",{confirmDeleteSupplier=null},{vm.deleteSupplier(confirmDeleteSupplier!!.id);confirmDeleteSupplier=null})}
    if(showOrder){OrderDialog(products,suppliers,onDismiss={showOrder=false})}
    if(showDashboard){DashboardDialog(vm,onDismiss={showDashboard=false})}
    if(showCosts){CostsDialog(fixedCosts,onAdd=vm::addFixedCost,onDelete=vm::deleteFixedCost,onDismiss={showCosts=false})}
    if(showObjectives){ObjectivesDialog(objectives,onAdd=vm::addObjective,onDelete={confirmDeleteObjective=it},onDismiss={showObjectives=false})}
    if(confirmDeleteObjective!=null){ConfirmDialog("Eliminar Objetivo","¿Seguro que quieres eliminar este objetivo?",{confirmDeleteObjective=null},{vm.deleteObjective(confirmDeleteObjective!!.id);confirmDeleteObjective=null})}
    if(showSettings){SettingsDialog(vm,onDismiss={showSettings=false},onExport={backupCreate.launch("gestion-soul-backup.json")},onImport={backupOpen.launch(arrayOf("application/json"))})}
    if(showInvoiceText!=null){TextResultDialog("Texto OCR de factura",showInvoiceText!!,{showInvoiceText=null},onUse={val raw=showInvoiceText?:"";showInvoiceText=null;vm.invoiceStructured(raw)})}
    if(showInvoiceReview){InvoiceReviewDialog(items=invoiceItems,onUpdate=vm::updateInvoiceItem,onDelete=vm::deleteInvoiceItem,onConfirm={vm.confirmInvoiceImport();showInvoiceReview=false},onDismiss={vm.clearInvoice();showInvoiceReview=false})}
    if(showRecipeUploadText!=null){TextResultDialog("Documento/carta procesado",showRecipeUploadText!!,{showRecipeUploadText=null})}
}

@Composable
private fun SoulHeader(onSettings:()->Unit){
    Row(Modifier.fillMaxWidth().padding(top=8.dp, bottom=4.dp), verticalAlignment=Alignment.CenterVertically) {
        Box(Modifier.weight(1f), contentAlignment = Alignment.Center) {
            Text(
                "Gestión Soul",
                fontWeight = FontWeight.Black,
                fontSize = 32.sp,
                color = Color.Transparent,
                modifier = Modifier.background(Brush.horizontalGradient(listOf(SoulAmber, SoulAmberSoft)), RoundedCornerShape(2.dp))
            )
        }
        Text("⚙", fontSize = 25.sp, color = SoulAmber, modifier = Modifier.clip(RoundedCornerShape(12.dp)).clickable { onSettings() }.padding(8.dp))
    }
}

@Composable
private fun MainSection(id:String,title:String,badge:Int,openSection:String?,onToggle:()->Unit,content:@Composable ColumnScope.()->Unit){
    Card(colors=CardDefaults.cardColors(containerColor=SoulPanel.copy(alpha=.98f)),shape=RoundedCornerShape(18.dp),modifier=Modifier.fillMaxWidth().animateContentSize().border(1.dp,SoulBorder,RoundedCornerShape(18.dp))){
        Column(Modifier.fillMaxWidth()){
            Row(Modifier.fillMaxWidth().clickable{onToggle()}.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Text(title,fontSize=17.sp,fontWeight=FontWeight.Black,color=SoulText,modifier=Modifier.weight(1f));if(badge>0){Box(Modifier.clip(RoundedCornerShape(50)).background(SoulAmber).padding(horizontal=9.dp,vertical=4.dp)){Text(badge.toString(),color=Color.Black,fontWeight=FontWeight.Black,fontSize=11.sp)}}Spacer(Modifier.width(8.dp));Text(if(openSection==id)"⌃" else"⌄",color=SoulAmber,fontSize=22.sp,fontWeight=FontWeight.Black)}
            AnimatedVisibility(openSection==id){Column(Modifier.padding(horizontal=14.dp,vertical=2.dp),content=content)}
        }
    }
}

@Composable
private fun SectionDivider(label:String){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Divider(Modifier.weight(1f),color=SoulBorder);Text(label,color=SoulMuted,fontWeight=FontWeight.Bold,fontSize=9.sp,modifier=Modifier.padding(horizontal=10.dp));Divider(Modifier.weight(1f),color=SoulBorder)}}

@Composable
private fun ActionButton(label:String,onClick:()->Unit,primary:Boolean=true,modifier:Modifier=Modifier.fillMaxWidth()){
    val colors=if(primary)ButtonDefaults.buttonColors(containerColor=SoulAmber,contentColor=Color.Black) else ButtonDefaults.outlinedButtonColors(contentColor=SoulText)
    if(primary)Button(onClick=onClick,modifier=modifier,heightIn(min=46.dp),colors=colors,shape=RoundedCornerShape(12.dp)){Text(label,fontWeight=FontWeight.Bold)}
    else OutlinedButton(onClick=onClick,modifier=modifier,heightIn(min=46.dp),colors=colors,shape=RoundedCornerShape(12.dp)){Text(label,fontWeight=FontWeight.Bold)}
}

@Composable
private fun StatCard(title:String,value:String,accent:Color=SoulAmber){Card(colors=CardDefaults.cardColors(containerColor=SoulPanel2),shape=RoundedCornerShape(14.dp),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(14.dp)){Text(title,color=SoulMuted,fontSize=9.sp,fontWeight=FontWeight.Black);Text(value,color=accent,fontSize=22.sp,fontWeight=FontWeight.Black,modifier=Modifier.padding(top=3.dp))}}}

@Composable
private fun ProductSection(products:List<Product>,categories:List<Category>,search:String,onSearch:(String)->Unit,onAdd:()->Unit,onCamera:()->Unit,onGallery:()->Unit,onFile:()->Unit,onCatalog:()->Unit,onEdit:(Product)->Unit,onDelete:(Product)->Unit){
    Column(verticalArrangement=Arrangement.spacedBy(10.dp)){ActionButton("＋ Añadir Producto Manualmente",onAdd);Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){ActionButton("📷 Tomar foto de factura",onCamera,false,Modifier.weight(1f));ActionButton("🖼 Cargar imagen",onGallery,false,Modifier.weight(1f))};ActionButton("📄 Cargar factura / documento",onFile,false);ActionButton("📚 Catálogo de Productos",onCatalog,false);SectionDivider("BUSCAR O GESTIONAR CATÁLOGO");SearchField(search,onSearch,"Buscar por nombre de producto...");if(search.isNotBlank()){Text("${products.filter{ParsingUtils.normalize(it.description).contains(ParsingUtils.normalize(search))}.size} resultados",color=SoulMuted,fontSize=11.sp);products.filter{ParsingUtils.normalize(it.description).contains(ParsingUtils.normalize(search))}.take(80).forEach{p->ProductRow(p,onEdit,onDelete)}} else {Text("Base de datos local: ${products.size} productos",color=SoulMuted,fontSize=11.sp)}}
}

@Composable
private fun ProductRow(p: Product, onEdit: (Product) -> Unit, onDelete: (Product) -> Unit) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SoulPanel2),
        shape = RoundedCornerShape(13.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(p.description, fontWeight = FontWeight.Bold, color = SoulText)
                Text("${p.category} · ${p.supplierCategory}", fontSize = 10.sp, color = SoulMuted)
                Text(
                    "Coste ${money.format(p.unitPrice)}€ · PVP ${money.format(p.sellingPrice)}€ · Margen ${money.format(p.profitMargin)}%",
                    fontSize = 10.sp,
                    color = if (p.profitMargin >= 0) SoulGreen else SoulRed
                )
            }
            Text("✎", color = SoulAmber, fontSize = 19.sp, modifier = Modifier.clickable { onEdit(p) }.padding(7.dp))
            Text("×", color = SoulRed, fontSize = 22.sp, modifier = Modifier.clickable { onDelete(p) }.padding(7.dp))
        }
    }
}

@Composable
private fun RecipeSection(
    recipes: List<Recipe>,
    categories: List<Category>,
    search: String,
    onSearch: (String) -> Unit,
    onAdd: () -> Unit,
    onEdit: (Recipe) -> Unit,
    onDelete: (Recipe) -> Unit,
    onImport: () -> Unit,
    onCatalog: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ActionButton("＋ Añadir Receta", onAdd)
        ActionButton("📄 Importar carta / recetas", onImport, false)
        ActionButton("📖 Catálogo de Recetas", onCatalog, false)
        SectionDivider("BUSCAR O GESTIONAR CATÁLOGO")
        SearchField(search, onSearch, "Buscar por nombre de receta...")
        if (search.isNotBlank()) {
            recipes.filter { ParsingUtils.normalize(it.description).contains(ParsingUtils.normalize(search)) }
                .take(80)
                .forEach { r -> RecipeRow(r, onEdit, onDelete) }
        } else {
            Text("Base de datos local: ${recipes.size} recetas", color = SoulMuted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun RecipeRow(r: Recipe, onEdit: (Recipe) -> Unit, onDelete: (Recipe) -> Unit) {
    Card(colors = CardDefaults.cardColors(containerColor = SoulPanel2), shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(r.description, fontWeight = FontWeight.Bold)
                Text("${r.type.replaceFirstChar { it.uppercase() }} · ${r.category} · PVP ${money.format(r.sellingPrice)}€", fontSize = 10.sp, color = SoulMuted)
                if (r.salesSuggestion != null) Text("Asistente de ventas: disponible", color = SoulAmberSoft, fontSize = 9.sp)
            }
            Text("✎", color = SoulAmber, fontSize = 19.sp, modifier = Modifier.clickable { onEdit(r) }.padding(7.dp))
            Text("×", color = SoulRed, fontSize = 22.sp, modifier = Modifier.clickable { onDelete(r) }.padding(7.dp))
        }
    }
}

@Composable
private fun SupplierSection(
    suppliers: List<Supplier>,
    onManage: (Supplier?) -> Unit,
    onAdd: () -> Unit,
    onDelete: (Supplier) -> Unit,
    onOrder: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.fillMaxWidth()) {
            ActionButton("🚚 Gestionar Proveedores", onAdd, primary = true, modifier = Modifier.weight(1f))
            ActionButton("📋 Gestionar Pedidos", onOrder, primary = false, modifier = Modifier.weight(1f))
        }
        suppliers.filter { it.id != "unassigned" }.forEach { supplier ->
            Card(colors = CardDefaults.cardColors(containerColor = SoulPanel2), shape = RoundedCornerShape(13.dp), modifier = Modifier.fillMaxWidth()) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(supplier.name, fontWeight = FontWeight.Bold)
                        Text(supplier.description, color = SoulMuted, fontSize = 10.sp)
                        supplier.phone?.let { Text("WhatsApp: $it", color = SoulAmberSoft, fontSize = 10.sp) }
                    }
                    Text("✎", color = SoulAmber, fontSize = 18.sp, modifier = Modifier.clickable { onManage(supplier) }.padding(7.dp))
                    Text("×", color = SoulRed, fontSize = 21.sp, modifier = Modifier.clickable { onDelete(supplier) }.padding(7.dp))
                }
            }
        }
    }
}

@Composable
private fun AnalysisUi(vm:MainViewModel,products:List<Product>,recipes:List<Recipe>,fixedCosts:List<FixedCost>,analysis:BusinessAnalysis?,showCosts:()->Unit,showDashboard:()->Unit,runAnalysis:()->Unit,busy:Boolean){Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){ActionButton("ESTRUCTURA · Costes fijos",showCosts,false,Modifier.weight(1f));ActionButton("Dashboard de Rentabilidad",showDashboard,false,Modifier.weight(1f))};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){StatCard("Margen de Seguridad",money.format(vm.safetyMargin())+" %",SoulGreen);StatCard("Punto de Equilibrio",money.format(vm.breakEven())+" €",Color(0xFF60A5FA))};Card(colors=CardDefaults.cardColors(containerColor=SoulPanel2),shape=RoundedCornerShape(15.dp)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(7.dp)){Text("Perfil Estratégico AI",fontSize=20.sp,fontWeight=FontWeight.Black,fontStyle=androidx.compose.ui.text.font.FontStyle.Italic);Text("Cruza ingredientes, recetas y costes fijos...",color=SoulMuted,fontSize=10.sp);ActionButton("ANALIZAR NEGOCIO CON IA",runAnalysis);if(analysis!=null){Text(analysis.businessType,fontWeight=FontWeight.Bold,color=SoulAmberSoft);BulletList("Puntos Fuertes",analysis.strengths);BulletList("Áreas de Mejora",analysis.improvementAreas);BulletList("Oportunidades",analysis.opportunities);Text(analysis.pricingStrategy,color=SoulText,fontSize=12.sp)}}}}}
@Composable private fun BulletList(title:String,items:List<String>){if(items.isNotEmpty()){Text(title,color=SoulAmber,fontWeight=FontWeight.Bold,fontSize=11.sp);items.take(8).forEach{Text("• $it",color=SoulMuted,fontSize=11.sp)}}}

@Composable
private fun MarketingUi(vm:MainViewModel,sales:List<SaleEntry>,objectives:List<MarketingObjective>,strategy:MarketingStrategy?,showObjectives:()->Unit,onImportSales:()->Unit,busy:Boolean){var timeframe by rememberSaveable{mutableStateOf("Mensual")};Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Row(horizontalArrangement=Arrangement.spacedBy(8.dp),modifier=Modifier.fillMaxWidth()){listOf("Semanal","Mensual","Anual").forEach{FilterChip(selected=timeframe==it,onClick={timeframe=it},label={Text(it)})}};ActionButton("＋ AÑADIR OBJETIVO",showObjectives);Text("${objectives.count{it.timeframe==timeframe}} objetivos activos · $timeframe",color=SoulMuted,fontSize=10.sp);ActionButton("Importar Reporte de Ventas",onImportSales,false);Card(colors=CardDefaults.cardColors(containerColor=SoulPanel2),shape=RoundedCornerShape(15.dp)){Column(Modifier.padding(14.dp),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("CRUZANDO DATOS HISTÓRICOS...",fontSize=10.sp,color=SoulMuted,fontWeight=FontWeight.Black);Text("${sales.size} registros de ventas",fontSize=11.sp,color=SoulText);ActionButton("ANALIZAR ESTACIONALIDAD Y TENDENCIAS",vm::generateMarketingStrategy);strategy?.let{Text("Plan de Crecimiento",fontWeight=FontWeight.Black,fontSize=20.sp,fontStyle=androidx.compose.ui.text.font.FontStyle.Italic);BulletList("Patrones Detectados",it.seasonalityInsights);BulletList("Ingeniería Promocional",it.promotionalEngineering);BulletList("Optimización de Menú",it.dynamicMenuOptimization);BulletList("Revenue Management",it.revenueManagement);BulletList("Plan de Acción",it.suggestedActionPlan)}}}}}

@Composable
private fun CommunityUi(vm:MainViewModel,brand:BrandManual?,objectives:List<MarketingObjective>,posts:List<SocialPost>,onBrandImport:()->Unit,busy:Boolean){val clipboard=LocalClipboardManager.current;Column(verticalArrangement=Arrangement.spacedBy(10.dp)){Row(verticalAlignment=Alignment.CenterVertically){Box(Modifier.size(48.dp).clip(RoundedCornerShape(50)).background(SoulAmber),contentAlignment=Alignment.Center){Text("CM",color=Color.Black,fontWeight=FontWeight.Black)}Column(Modifier.padding(start=10.dp)){Text("Content Studio AI Professional",fontWeight=FontWeight.Black,color=SoulAmber,fontSize=13.sp);Text(if(brand!=null)"Tono: ${brand.toneOfVoice ?: "cargado localmente"}" else "Sin manual de marca",fontSize=10.sp,color=SoulMuted)}};ActionButton("Cargar Manual de Marca",onBrandImport,false);if(objectives.isEmpty())Text("Sin objetivos en bloque 5",color=SoulRed,fontSize=10.sp);else Text("${objectives.size} objetivos disponibles para vincular",color=SoulMuted,fontSize=10.sp);ActionButton("GENERAR IDEA SOCIAL",{val target=objectives.firstOrNull();vm.generateSocialIdea(target)});posts.forEach{p->Card(colors=CardDefaults.cardColors(containerColor=SoulPanel2),shape=RoundedCornerShape(14.dp)){Column(Modifier.padding(12.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){Text(p.platform.uppercase(),color=SoulAmber,fontWeight=FontWeight.Black,fontSize=9.sp);Text(p.caption,color=SoulText,fontSize=12.sp);Text(p.hashtags.joinToString(" "),color=SoulMuted,fontSize=10.sp);p.imagePrompt?.let{Text("Prompt Imagen: $it",fontSize=9.sp,color=SoulMuted,modifier=Modifier.clickable{clipboard.setText(AnnotatedString(it))})};p.videoPrompt?.let{Text("Prompt Vídeo: $it",fontSize=9.sp,color=SoulMuted,modifier=Modifier.clickable{clipboard.setText(AnnotatedString(it))})}}}};if(posts.isEmpty()){Text("Sin contenido activo",fontWeight=FontWeight.Black,color=SoulMuted);Text("Selecciona un objetivo del bloque 5 para que la IA diseñe un calendario editorial coherente con tu estrategia.",fontSize=10.sp,color=Color(0xFF6B7280))}}}

@Composable private fun SearchField(value:String,onChange:(String)->Unit,placeholder:String){OutlinedTextField(value,onChange,Modifier.fillMaxWidth(),label={Text(placeholder)},singleLine=true,colors=androidx.compose.material3.OutlinedTextFieldDefaults.colors(focusedBorderColor=SoulAmber,unfocusedBorderColor=SoulBorder,focusedLabelColor=SoulAmber,unfocusedLabelColor=SoulMuted))}

@Composable
private fun CatalogDialog(title:String,categories:List<Category>,itemCategoryNames:List<String>,onDismiss:()->Unit,onManage:()->Unit,onSelect:(Category)->Unit){
    val counts=categories.associate{cat->cat.id to itemCategoryNames.count{ParsingUtils.normalize(it)==ParsingUtils.normalize(cat.name)}}
    AlertDialog(onDismissRequest=onDismiss,title={Text(title,fontWeight=FontWeight.Black)},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
        if(categories.isEmpty())Text("Aún no se han creado categorías.",color=SoulMuted)
        else categories.forEach{cat->
            val count=counts[cat.id]?:0
            if(count>0 || cat.name.equals("Sin Categoría",true) || cat.name.equals("Otros",true)){
                Card(colors=CardDefaults.cardColors(containerColor=SoulPanel2),shape=RoundedCornerShape(12.dp),modifier=Modifier.fillMaxWidth().clickable{onSelect(cat)}){Row(Modifier.padding(14.dp),verticalAlignment=Alignment.CenterVertically){Text(cat.name,modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold);Text("($count)",color=SoulAmber,fontWeight=FontWeight.Black)}}
            }
        }
    }},confirmButton={Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton(onClick=onManage){Text("MODIFICAR",color=SoulText)};Button(onClick=onDismiss,colors=ButtonDefaults.buttonColors(containerColor=SoulAmber,contentColor=Color.Black)){Text("CERRAR")}}})
}

@Composable
private fun CategoryItemsDialog(title:String,items:List<Any>,onDismiss:()->Unit,onEdit:(Any)->Unit,onDelete:(Any)->Unit){
    AlertDialog(onDismissRequest=onDismiss,title={Text(title,fontWeight=FontWeight.Black)},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){
        if(items.isEmpty()) Text("No hay elementos en esta categoría.",color=SoulMuted)
        items.forEach{item->when(item){is Product->ProductRow(item,{onEdit(item)},{onDelete(item)});is Recipe->RecipeRow(item,{onEdit(item)},{onDelete(item)})}}
    }},confirmButton={TextButton(onClick=onDismiss){Text("CERRAR",color=SoulAmber)}})
}

@Composable
private fun ManageCategoriesDialog(title:String,categories:List<Category>,onAdd:(String)->Unit,onRename:(Category,String)->Unit,onDelete:(Category)->Unit,onDismiss:()->Unit){
    var newName by remember{mutableStateOf("")}
    var editing by remember{mutableStateOf<Category?>(null)}
    var editName by remember{mutableStateOf("")}
    AlertDialog(onDismissRequest=onDismiss,title={Text(title,fontWeight=FontWeight.Black)},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
        Text("Renombra o elimina categorías existentes. Los cambios se aplican a los elementos asociados.",fontSize=10.sp,color=SoulMuted)
        SimpleField("Nombre de la nueva categoría",newName){newName=it}
        ActionButton("AÑADIR CATEGORÍA",{if(newName.isNotBlank()){onAdd(newName.trim());newName=""}})
        categories.filterNot{it.name.equals("Sin Categoría",true) || it.name.equals("Otros",true)}.forEach{cat->
            Card(colors=CardDefaults.cardColors(containerColor=SoulPanel2),shape=RoundedCornerShape(12.dp)){Column(Modifier.padding(10.dp)){
                if(editing?.id==cat.id){SimpleField("Nuevo nombre",editName){editName=it};Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){TextButton(onClick={onRename(cat,editName);editing=null}){Text("GUARDAR",color=SoulAmber)};TextButton(onClick={editing=null}){Text("CANCELAR",color=SoulMuted)}}}
                else {Row(verticalAlignment=Alignment.CenterVertically){Text(cat.name,modifier=Modifier.weight(1f),fontWeight=FontWeight.Bold);TextButton(onClick={editing=cat;editName=cat.name}){Text("EDITAR",color=SoulAmber)};TextButton(onClick={onDelete(cat)}){Text("BORRAR",color=SoulRed)}}}
            }}
        }
    }},confirmButton={TextButton(onClick=onDismiss){Text("CERRAR",color=SoulAmber)}})
}

@Composable
private fun CalculatedValueCard(
    title: String,
    value: String,
    isHighlighted: Boolean = false,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = if (isHighlighted) Color(0xFF3A2F0A) else SoulPanel2),
        shape = RoundedCornerShape(10.dp)
    ) {
        Column(Modifier.padding(9.dp)) {
            Text(title, color = SoulMuted, fontSize = 8.sp, fontWeight = FontWeight.Black)
            Text(value, color = if (isHighlighted) SoulAmberSoft else SoulText, fontSize = 15.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun ProductDialog(
    existing: Product?,
    categories: List<Category>,
    suppliers: List<Supplier>,
    supplierCats: List<Category>,
    onDismiss: () -> Unit,
    onSave: (Product?, String, String, String?, String, Double, Double, Double, Double, Double) -> Unit
) {
    var desc by remember(existing) { mutableStateOf(existing?.description ?: "") }
    var cat by remember(existing) { mutableStateOf(existing?.category ?: categories.firstOrNull()?.name ?: "Sin Categoría") }
    var supplier by remember(existing) { mutableStateOf(existing?.supplierId ?: "") }
    var sc by remember(existing) { mutableStateOf(existing?.supplierCategory ?: "Sin Categoría de Proveedor") }
    var cost by remember(existing) { mutableStateOf(existing?.cost?.toString() ?: "") }
    var dis by remember(existing) { mutableStateOf(existing?.discount?.toString() ?: "0") }
    var vat by remember(existing) { mutableStateOf(existing?.vat?.toString() ?: "10") }
    var servings by remember(existing) { mutableStateOf(existing?.servingsPerUnit?.toString() ?: "1") }
    var pvp by remember(existing) { mutableStateOf(existing?.sellingPrice?.toString() ?: "") }
    var showHistory by remember { mutableStateOf(false) }

    val c = ParsingUtils.parseNumber(cost)
    val d = ParsingUtils.parseNumber(dis)
    val u = c * (1 - d / 100)
    val v = ParsingUtils.parseNumber(vat)
    val s = ParsingUtils.parseNumber(servings).coerceAtLeast(1.0)
    val sell = ParsingUtils.parseNumber(pvp)
    val priceWithVat = u * (1 + v / 100)
    val perServing = priceWithVat / s
    val profit = sell / 1.10 - u
    val margin = if (u != 0.0) profit / u * 100 else 0.0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Añadir Producto Manualmente" else "Editar Producto", fontWeight = FontWeight.Black) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SimpleField("Nombre del Producto", desc) { desc = it }
                Text("Categoría de Producto", color = SoulMuted, fontSize = 11.sp)
                SelectionMenu(cat, categories.map { it.name }) { cat = it }
                Text("Proveedor", color = SoulMuted, fontSize = 11.sp)
                SelectionMenu(supplier.ifBlank { "No Asignado" }, listOf("No Asignado") + suppliers.filter { it.id != "unassigned" }.map { it.name }) { sel ->
                    supplier = suppliers.firstOrNull { it.name == sel }?.id ?: ""
                }
                Text("Categoría de Proveedor", color = SoulMuted, fontSize = 11.sp)
                SelectionMenu(sc, (listOf("Sin Categoría de Proveedor") + supplierCats.filter { it.supplierId == supplier || supplier.isBlank() }.map { it.name }).distinct()) { sc = it }
                NumericField("Costo (€)", cost) { cost = it }
                NumericField("Dto. (%)", dis) { dis = it }
                NumericField("I.V.A. Soportado (%)", vat) { vat = it }
                NumericField("Servings / Ud.", servings) { servings = it }
                NumericField("PVP (€)", pvp) { pvp = it }

                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    CalculatedValueCard(title = "Precio con Dto.", value = "${money.format(u)}€", modifier = Modifier.weight(1f))
                    CalculatedValueCard(title = "Precio con I.V.A.", value = "${money.format(priceWithVat)}€", modifier = Modifier.weight(1f))
                    CalculatedValueCard(title = "Precio por Unidad", value = "${money.format(perServing)}€", isHighlighted = true, modifier = Modifier.weight(1f))
                }
                Card(colors = CardDefaults.cardColors(containerColor = SoulPanel2), shape = RoundedCornerShape(10.dp)) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        Text("Beneficio estimado ${money.format(profit)}€", fontSize = 11.sp, color = SoulText)
                        Text("Margen ${money.format(margin)}%", fontSize = 11.sp, color = if (margin >= 0) SoulGreen else SoulRed, fontWeight = FontWeight.Bold)
                    }
                }
                if (existing != null && existing.priceHistory.isNotEmpty()) {
                    HorizontalDivider(color = SoulBorder)
                    OutlinedButton(
                        onClick = { showHistory = true },
                        modifier = Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = SoulText)
                    ) { Text("▥  VER HISTORIAL DE PRECIOS") }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(existing, desc.trim(), cat, supplier.ifBlank { null }, sc, c, d, v, s, sell) },
                colors = ButtonDefaults.buttonColors(containerColor = SoulAmber, contentColor = Color.Black),
                enabled = desc.isNotBlank()
            ) { Text("GUARDAR") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("CANCELAR", color = SoulMuted) } }
    )

    if (showHistory && existing != null) {
        PriceHistoryDialog(existing.priceHistory, onDismiss = { showHistory = false })
    }
}

@Composable
private fun PriceHistoryDialog(history: List<PriceHistory>, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Historial de Precios", fontWeight = FontWeight.Black) },
        text = {
            Column(Modifier.heightIn(max = 460.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                if (history.isEmpty()) Text("No hay historial de precios.", color = SoulMuted)
                history.asReversed().forEach { h ->
                    Card(colors = CardDefaults.cardColors(containerColor = SoulPanel2), shape = RoundedCornerShape(10.dp)) {
                        Column(Modifier.fillMaxWidth().padding(10.dp)) {
                            Text(h.date.take(10), color = SoulMuted, fontSize = 9.sp)
                            Text("Precio Dto. ${money.format(h.pricePerUnit)}€", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text("Precio c/IVA ${money.format(h.priceWithVat)}€ · Por unidad ${money.format(h.pricePerServing)}€", color = SoulText, fontSize = 10.sp)
                        }
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("VOLVER", color = SoulAmber) } }
    )
}

@Composable
private fun RecipeDialog(
    existing: Recipe?,
    recipeCategories: List<Category>,
    productCategories: List<Category>,
    products: List<Product>,
    onDismiss: () -> Unit,
    onGenerateSalesSuggestion: suspend (String, String, Double, Double) -> SalesSuggestion,
    onSave: (Recipe?, String, Double, String, String, List<RecipeProduct>, List<RecipeProduct>, List<DynamicProductGroup>, Map<String,String>, SalesSuggestion?) -> Unit
) {
    var desc by remember(existing) { mutableStateOf(existing?.description ?: "") }
    var pvp by remember(existing) { mutableStateOf(existing?.sellingPrice?.takeIf { it > 0 }?.toString() ?: "") }
    var cat by remember(existing) { mutableStateOf(existing?.category ?: recipeCategories.firstOrNull()?.name ?: "Otros") }
    var type by remember(existing) { mutableStateOf(existing?.type ?: "simple") }
    var selected by remember(existing) { mutableStateOf((existing?.products ?: emptyList()).associate { it.productId to it.quantity }.toMutableMap()) }
    var fixedSelected by remember(existing) { mutableStateOf((existing?.fixedProducts ?: emptyList()).associate { it.productId to it.quantity }.toMutableMap()) }
    var groups by remember(existing) {
        mutableStateOf((existing?.dynamicProductGroups ?: emptyList()).mapIndexed { index, g ->
            g.copy(id = "group-$index-${existing?.id ?: "new"}")
        }.toMutableList())
    }
    var dynamicSelections by remember(existing) {
        mutableStateOf((existing?.defaultSelections ?: emptyMap()).mapKeys { "group-${it.key}-${existing?.id ?: "new"}" }.toMutableMap())
    }
    var search by remember { mutableStateOf("") }
    var fixedSearch by remember { mutableStateOf("") }
    var simulatedPvp by remember(existing) { mutableStateOf(existing?.sellingPrice ?: 0.0) }
    var targetMargin by remember { mutableStateOf("") }
    var salesSuggestion by remember(existing) { mutableStateOf(existing?.salesSuggestion) }
    var generatingSalesSuggestion by remember { mutableStateOf(false) }
    val suggestionScope = rememberCoroutineScope()

    fun productCost(id: String): Double = products.firstOrNull { it.id == id }?.let(::productCostFor) ?: 0.0
    fun listCost(map: Map<String, Double>): Double = map.entries.sumOf { (id, qty) -> productCost(id) * qty }
    fun dynamicCost(): Double = groups.sumOf { g -> dynamicSelections[g.id]?.let { productCost(it) * g.quantity } ?: 0.0 }
    val totalCost = if (type == "dynamic") listCost(fixedSelected) + dynamicCost() else listCost(selected)
    val sell = ParsingUtils.parseNumber(pvp)
    val profit = sell - totalCost
    val margin = if (sell > 0) profit / sell * 100.0 else 0.0

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Nueva Receta" else "Editar Receta", fontWeight = FontWeight.Black) },
        text = {
            Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SimpleField("Nombre de la Receta", desc) { desc = it }
                NumericField("PVP (€)", pvp) { pvp = it }
                Text("Categoría", color = SoulMuted, fontSize = 11.sp)
                SelectionMenu(cat, recipeCategories.map { it.name }) { cat = it }
                Text("Tipo de Receta", color = SoulMuted, fontSize = 11.sp)
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(SoulPanel2).padding(4.dp)) {
                    FilterChip(selected = type == "simple", onClick = { type = "simple" }, label = { Text("Simple") })
                    Spacer(Modifier.width(6.dp))
                    FilterChip(selected = type == "dynamic", onClick = { type = "dynamic" }, label = { Text("Dinámica") })
                }

                if (type == "dynamic") {
                    SectionDivider("CALCULADORA DE COMBINADOS")
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("Grupos dinámicos", color = SoulText, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        OutlinedButton(onClick = {
                            productCategories.firstOrNull()?.let { first ->
                                val id = "group-${UUID.randomUUID()}"
                                groups = (groups + DynamicProductGroup(first.id, 1.0).copy(id = id)).toMutableList()
                            }
                        }) { Text("+ AÑADIR GRUPO", color = SoulAmber) }
                    }
                    groups.forEachIndexed { index, group ->
                        val category = productCategories.firstOrNull { it.id == group.categoryId }
                        val categoryProducts = products.filter { ParsingUtils.normalize(it.category) == ParsingUtils.normalize(category?.name ?: "") }
                        Card(colors = CardDefaults.cardColors(containerColor = SoulPanel2), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text("Grupo ${index + 1}", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                                    Text("×", color = SoulRed, modifier = Modifier.clickable { val next = groups.toMutableList(); next.removeAt(index); groups = next; dynamicSelections = dynamicSelections.filterKeys { it != group.id }.toMutableMap() }.padding(6.dp))
                                }
                                Text("Categoría de producto", color = SoulMuted, fontSize = 10.sp)
                                SelectionMenu(category?.name ?: "Selecciona categoría", productCategories.map { it.name }) { selectedName ->
                                    val newCategory = productCategories.firstOrNull { it.name == selectedName } ?: return@SelectionMenu
                                    val next = groups.toMutableList()
                                    next[index] = group.copy(categoryId = newCategory.id)
                                    groups = next
                                    dynamicSelections = dynamicSelections.toMutableMap().apply { remove(group.id) }
                                }
                                Text("Cantidad: ${group.quantity.toInt()}", color = SoulMuted, fontSize = 10.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    OutlinedButton(onClick = { val next=groups.toMutableList(); next[index]=group.copy(quantity=(group.quantity-1).coerceAtLeast(1.0)); groups=next }) { Text("−") }
                                    OutlinedButton(onClick = { val next=groups.toMutableList(); next[index]=group.copy(quantity=group.quantity+1); groups=next }) { Text("+") }
                                }
                                if (categoryProducts.isEmpty()) {
                                    Text("No hay productos en esta categoría.", color = SoulMuted, fontSize = 10.sp)
                                } else {
                                    categoryProducts.take(50).forEach { pr ->
                                        Row(Modifier.fillMaxWidth().clickable { dynamicSelections = dynamicSelections.toMutableMap().apply { put(group.id, pr.id) } }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                            Text(if (dynamicSelections[group.id] == pr.id) "☑" else "□", color = if (dynamicSelections[group.id] == pr.id) SoulAmber else SoulMuted, fontSize = 17.sp)
                                            Text(pr.description, Modifier.weight(1f), fontSize = 10.sp)
                                            Text("${money.format(productCostFor(pr))}€", color = SoulMuted, fontSize = 9.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                SectionDivider(if (type == "simple") "INGREDIENTES" else "INGREDIENTES FIJOS")
                SearchField(if (type == "simple") search else fixedSearch, { if (type == "simple") search = it else fixedSearch = it }, "Buscar producto...")
                val activeMap = if (type == "simple") selected else fixedSelected
                val activeSearch = if (type == "simple") search else fixedSearch
                products.filter { activeSearch.isBlank() || ParsingUtils.normalize(it.description).contains(ParsingUtils.normalize(activeSearch)) }.take(45).forEach { pr ->
                    val qty = activeMap[pr.id]
                    Row(Modifier.fillMaxWidth().clickable {
                        if (qty == null) {
                            if (type == "simple") selected = selected.toMutableMap().apply { put(pr.id, 1.0) }
                            else fixedSelected = fixedSelected.toMutableMap().apply { put(pr.id, 1.0) }
                        } else {
                            if (type == "simple") selected = selected.toMutableMap().apply { remove(pr.id) }
                            else fixedSelected = fixedSelected.toMutableMap().apply { remove(pr.id) }
                        }
                    }.padding(vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (qty == null) "□" else "☑", color = if (qty == null) SoulMuted else SoulAmber, fontSize = 17.sp)
                        Text(pr.description, Modifier.weight(1f), fontSize = 10.sp)
                        if (qty != null) {
                            OutlinedTextField(value = qty.toString(), onValueChange = { value ->
                                val parsed = ParsingUtils.parseNumber(value).coerceAtLeast(1.0)
                                if (type == "simple") selected = selected.toMutableMap().apply { put(pr.id, parsed) }
                                else fixedSelected = fixedSelected.toMutableMap().apply { put(pr.id, parsed) }
                            }, modifier = Modifier.width(85.dp), singleLine = true)
                        }
                    }
                }

                Card(colors = CardDefaults.cardColors(containerColor = SoulPanel2), shape = RoundedCornerShape(10.dp)) {
                    Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text("Costo Receta ${money.format(totalCost)}€", color = SoulAmberSoft, fontWeight = FontWeight.Bold)
                        Text("Beneficio Bruto ${money.format(profit)}€", color = SoulText, fontSize = 11.sp)
                        Text("Margen ${money.format(margin)}%", fontSize = 11.sp, color = if (margin >= 0) SoulGreen else SoulRed, fontWeight = FontWeight.Bold)
                    }
                }

                SectionDivider("SIMULADOR DE PRECIOS Y ESCANDALLO")
                NumericField("Simular PVP (€)", if (simulatedPvp == 0.0) "" else simulatedPvp.toString()) { simulatedPvp = ParsingUtils.parseNumber(it) }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    CalculatedValueCard("Beneficio Simulado", "${money.format(simulatedPvp - totalCost)}€", modifier = Modifier.weight(1f))
                    val simMargin = if (simulatedPvp > 0) (simulatedPvp - totalCost) / simulatedPvp * 100 else 0.0
                    CalculatedValueCard("Margen Simulado", "${money.format(simMargin)}%", isHighlighted = true, modifier = Modifier.weight(1f))
                }
                NumericField("Margen Objetivo (%)", targetMargin) { targetMargin = it }
                val tm = ParsingUtils.parseNumber(targetMargin)
                val suggested = if (tm in 0.01..99.99 && totalCost > 0) totalCost / (1 - tm / 100) else 0.0
                CalculatedValueCard("PVP Sugerido", if (suggested > 0) "${money.format(suggested)}€" else "---", isHighlighted = true)

                SectionDivider("ASISTENTE DE VENTAS IA")
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("Ideas de venta para esta receta", modifier = Modifier.weight(1f), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    TextButton(
                        onClick = {
                            generatingSalesSuggestion = true
                            suggestionScope.launch {
                                try {
                                    salesSuggestion = onGenerateSalesSuggestion(desc.trim(), cat, totalCost, sell)
                                } catch (_: Exception) {
                                    salesSuggestion = SalesSuggestion(
                                        "No se pudieron generar ideas avanzadas; puedes usar el catálogo y el margen como referencia.",
                                        listOf("Ofrece una versión premium o un complemento de alto margen."),
                                        listOf("Relaciona la receta con una segunda consumición del catálogo."),
                                        "Te recomiendo esta opción por su relación entre precio, coste y experiencia."
                                    )
                                } finally { generatingSalesSuggestion = false }
                            }
                        },
                        enabled = sell > 0 && !generatingSalesSuggestion
                    ) { Text(if (salesSuggestion == null) "GENERAR IDEAS" else "REGENERAR", color = SoulAmber) }
                }
                if (generatingSalesSuggestion) { CircularProgressIndicator(Modifier.size(22.dp), color = SoulAmber) }
                salesSuggestion?.let { suggestion ->
                    Text("Descripción para Menú", color = SoulAmber, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text("\"${suggestion.menuDescription}\"", color = SoulText, fontSize = 10.sp)
                    Text("Venta Adicional", color = SoulAmber, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    suggestion.upsellSuggestions.forEach { Text("• $it", color = SoulText, fontSize = 10.sp) }
                    Text("Venta Cruzada", color = SoulAmber, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    suggestion.crossSellSuggestions.forEach { Text("• $it", color = SoulText, fontSize = 10.sp) }
                    Text("Argumentario de Venta", color = SoulAmber, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    Text(suggestion.salesScript, color = SoulText, fontSize = 10.sp)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val dynamic = groups.map { it.copy(id = it.id) }
                    val selections = dynamic.mapIndexedNotNull { index, g -> dynamicSelections[g.id]?.let { index.toString() to it } }.toMap()
                    onSave(
                        existing,
                        desc.trim(),
                        sell,
                        cat,
                        type,
                        selected.map { RecipeProduct(it.key, it.value) },
                        fixedSelected.map { RecipeProduct(it.key, it.value) },
                        dynamic,
                        selections,
                        salesSuggestion
                    )
                },
                colors = ButtonDefaults.buttonColors(containerColor = SoulAmber, contentColor = Color.Black),
                enabled = desc.isNotBlank() && sell > 0
            ) { Text("GUARDAR") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("CANCELAR", color = SoulMuted) } }
    )
}

private fun productCostFor(p:Product):Double{val withVat=p.unitPrice*(1+p.vat/100);return withVat/p.servingsPerUnit.coerceAtLeast(1.0)}

@Composable private fun SimpleField(label:String,value:String,onValue:(String)->Unit)=OutlinedTextField(value,onValue,modifier=Modifier.fillMaxWidth(),label={Text(label)},singleLine=true,colors=androidx.compose.material3.OutlinedTextFieldDefaults.colors(focusedBorderColor=SoulAmber,unfocusedBorderColor=SoulBorder,focusedLabelColor=SoulAmber,unfocusedLabelColor=SoulMuted))
@Composable private fun NumericField(label:String,value:String,onValue:(String)->Unit)=OutlinedTextField(value,onValue,modifier=Modifier.fillMaxWidth(),label={Text(label)},singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal),colors=androidx.compose.material3.OutlinedTextFieldDefaults.colors(focusedBorderColor=SoulAmber,unfocusedBorderColor=SoulBorder,focusedLabelColor=SoulAmber,unfocusedLabelColor=SoulMuted))
@Composable private fun TextFieldMini(value:String,onValue:(String)->Unit)=OutlinedTextField(value,onValue,modifier=Modifier.width(75.dp),singleLine=true,keyboardOptions=KeyboardOptions(keyboardType=KeyboardType.Decimal))
@Composable private fun SelectionMenu(current:String,items:List<String>,onPick:(String)->Unit){var exp by remember{mutableStateOf(false)};Box{OutlinedButton(onClick={exp=true},modifier=Modifier.fillMaxWidth(),colors=ButtonDefaults.outlinedButtonColors(contentColor=SoulText),shape=RoundedCornerShape(10.dp)){Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text(current,modifier=Modifier.weight(1f));Text("⌄",color=SoulAmber)}};DropdownMenu(expanded=exp,onDismissRequest={exp=false}){items.take(60).forEach{DropdownMenuItem(text={Text(it)},onClick={onPick(it);exp=false})}}}}

@Composable private fun SupplierDialog(
    existing: Supplier?,
    onDismiss: () -> Unit,
    onSave: (Supplier?, String, String, String) -> Unit
) {
    var n by remember(existing) { mutableStateOf(existing?.name ?: "") }
    var d by remember(existing) { mutableStateOf(existing?.description ?: "") }
    var ph by remember(existing) { mutableStateOf(existing?.phone ?: "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Nuevo Proveedor" else "Editar Proveedor", fontWeight = FontWeight.Black) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                SimpleField("Nombre del Proveedor", n) { n = it }
                SimpleField("Descripción / Notas", d) { d = it }
                SimpleField("Teléfono (WhatsApp)", ph) { ph = it }
            }
        },
        confirmButton = {
            Button(onClick = { onSave(existing, n.trim(), d.trim(), ph.trim()) }, colors = ButtonDefaults.buttonColors(containerColor = SoulAmber, contentColor = Color.Black), enabled = n.isNotBlank()) { Text("GUARDAR") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("CANCELAR", color = SoulMuted) } }
    )
}

@Composable
private fun OrderDialog(products: List<Product>, suppliers: List<Supplier>, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val prefs = context.getSharedPreferences("order_draft", Context.MODE_PRIVATE)
    var search by remember { mutableStateOf("") }
    var step by rememberSaveable { mutableStateOf(0) }
    var order by remember { mutableStateOf(loadOrderDraft(prefs)) }
    val visible = products.filter { search.isBlank() || ParsingUtils.normalize(it.description).contains(ParsingUtils.normalize(search)) }.take(80)

    fun persist(next: Map<String, Double>) {
        order = next
        prefs.edit().putString("json", JSONObject(next.filterValues { it > 0 }).toString()).apply()
    }
    fun clear() { prefs.edit().remove("json").apply() }
    fun greeting(): String {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when (hour) { in 5..11 -> "Buenos días"; in 12..19 -> "Buenas tardes"; else -> "Buenas noches" }
    }
    fun supplierMessage(supplier: Supplier, items: List<Pair<Product, Double>>): String = buildString {
        append("Hola ${supplier.name}.\n\n${greeting()}.\n\nEste es el pedido para la semana:\n\n")
        items.forEach { (product, qty) -> append("- ${qty.prettyQuantity()} x ${product.description}\n") }
    }
    fun sendWhatsApp(supplier: Supplier, items: List<Pair<Product, Double>>) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, supplierMessage(supplier, items).trim())
            if (!supplier.phone.isNullOrBlank()) setPackage("com.whatsapp")
        }
        try { context.startActivity(intent) } catch (_: Exception) { context.startActivity(Intent.createChooser(intent, "Enviar pedido por WhatsApp")) }
    }

    val groups = order.filter { it.value > 0 }.entries
        .groupBy { entry -> products.firstOrNull { product -> product.id == entry.key }?.supplierId ?: "unassigned" }
        .mapValues { (_, entries) -> entries.mapNotNull { entry -> products.firstOrNull { it.id == entry.key }?.let { it to entry.value } } }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (step == 0) "Crear Nuevo Pedido" else "Resumen del Pedido por Proveedor", fontWeight = FontWeight.Black) },
        text = {
            Column(Modifier.heightIn(max = 620.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (step == 0) {
                    Text("Introduce la cantidad de cada producto que deseas pedir.", fontSize = 10.sp, color = SoulMuted)
                    SearchField(search, { search = it }, "Buscar producto para añadir al pedido...")
                    visible.groupBy { it.category }.forEach { (category, items) ->
                        Text(category, color = SoulAmber, fontWeight = FontWeight.Black, fontSize = 11.sp)
                        items.forEach { product ->
                            val qty = order[product.id] ?: 0.0
                            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(product.description, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                    Text(suppliers.firstOrNull { it.id == product.supplierId }?.name ?: "Productos no asignados", fontSize = 9.sp, color = SoulMuted)
                                }
                                OutlinedTextField(
                                    value = if (qty > 0) qty.prettyQuantity() else "",
                                    onValueChange = { raw ->
                                        val value = ParsingUtils.parseNumber(raw)
                                        val next = order.toMutableMap()
                                        if (value > 0) next[product.id] = value else next.remove(product.id)
                                        persist(next)
                                    },
                                    modifier = Modifier.width(86.dp),
                                    singleLine = true,
                                    label = { Text("Cantidad") }
                                )
                            }
                        }
                    }
                    if (order.any { it.value > 0 }) {
                        val total = order.filter { it.value > 0 }.entries.sumOf { entry -> products.firstOrNull { it.id == entry.key }?.let { product -> productCostFor(product) * entry.value * (1 + product.vat / 100) } ?: 0.0 }
                        Text("Productos en pedido: ${order.count { it.value > 0 }}", color = SoulGreen, fontSize = 10.sp)
                        Text("Coste estimado con IVA: ${money.format(total)}€", fontWeight = FontWeight.Black)
                    } else {
                        Text("No se encontraron productos seleccionados.", color = SoulMuted, fontSize = 10.sp)
                    }
                } else {
                    if (groups.isEmpty()) Text("No hay productos en el pedido.", color = SoulMuted)
                    groups.forEach { (supplierId, items) ->
                        val supplier = suppliers.firstOrNull { it.id == supplierId } ?: Supplier("unassigned", "Productos no asignados")
                        Card(colors = CardDefaults.cardColors(containerColor = SoulPanel2), shape = RoundedCornerShape(12.dp)) {
                            Column(Modifier.padding(11.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text(supplier.name, color = SoulAmber, fontWeight = FontWeight.Black)
                                items.forEach { (product, qty) ->
                                    Row(Modifier.fillMaxWidth()) {
                                        Text(product.description, Modifier.weight(1f), fontSize = 10.sp)
                                        Text("${qty.prettyQuantity()} uds.", fontSize = 10.sp, color = SoulMuted)
                                        Text("${money.format(productCostFor(product) * qty * (1 + product.vat / 100))}€", fontSize = 10.sp)
                                    }
                                }
                                val subtotal = items.sumOf { (product, qty) -> productCostFor(product) * qty * (1 + product.vat / 100) }
                                HorizontalDivider(color = SoulBorder)
                                Text("Subtotal con IVA: ${money.format(subtotal)}€", fontWeight = FontWeight.Bold, color = SoulGreen, fontSize = 11.sp)
                                ActionButton("ENVIAR ESTE PEDIDO POR WHATSAPP", { sendWhatsApp(supplier, items) }, false)
                            }
                        }
                    }
                    if (groups.isNotEmpty()) {
                        val text = groups.values.flatten().joinToString("\n") { (product, qty) -> "${qty.prettyQuantity()} x ${product.description}" }
                        ActionButton("COPIAR PEDIDO", { clipboard.setText(AnnotatedString(text)) }, false)
                    }
                }
            }
        },
        confirmButton = {
            if (step == 0) {
                Button(onClick = { step = 1 }, enabled = order.any { it.value > 0 }, colors = ButtonDefaults.buttonColors(containerColor = SoulAmber, contentColor = Color.Black)) { Text("CONFIRMAR PEDIDO") }
            } else {
                Button(onClick = { clear(); onDismiss() }, colors = ButtonDefaults.buttonColors(containerColor = SoulAmber, contentColor = Color.Black)) { Text("HECHO") }
            }
        },
        dismissButton = {
            if (step == 1) TextButton(onClick = { step = 0 }) { Text("VOLVER", color = SoulMuted) }
            else TextButton(onClick = onDismiss) { Text("CERRAR", color = SoulMuted) }
        }
    )
}

private fun Double.prettyQuantity(): String = if (this % 1.0 == 0.0) this.toInt().toString() else "%.2f".format(java.util.Locale.getDefault(), this)

private fun loadOrderDraft(prefs:android.content.SharedPreferences):Map<String,Double>{
    val raw=prefs.getString("json",null)?:return emptyMap()
    return runCatching{val o=JSONObject(raw);buildMap{val keys=o.keys();while(keys.hasNext()){val k=keys.next();put(k,o.optDouble(k,0.0))}}}.getOrDefault(emptyMap())
}

@Composable private fun DashboardDialog(vm:MainViewModel,onDismiss:()->Unit){val rows=vm.productDashboard();AlertDialog(onDismissRequest=onDismiss,title={Text("Dashboard de Rentabilidad de Recetas",fontWeight=FontWeight.Black)},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(7.dp)){if(vm.products.value.isEmpty())Text("No hay suficientes datos.",color=SoulMuted);Text("Top 5 Recetas Estrella",color=SoulAmber,fontWeight=FontWeight.Black);vm.recipes.value.sortedByDescending{recipeMargin(vm,it)}.take(5).forEach{Text("• ${it.description} — ${money.format(recipeMargin(vm,it))}%",fontSize=11.sp)};Text("Top 5 Recetas a Revisar",color=SoulRed,fontWeight=FontWeight.Black);vm.recipes.value.sortedBy{recipeMargin(vm,it)}.take(5).forEach{Text("• ${it.description} — ${money.format(recipeMargin(vm,it))}%",fontSize=11.sp)};Text("Beneficio Medio por Categoría",fontSize=18.sp,fontWeight=FontWeight.Black);rows.take(12).forEach{Text("${it.category}: ${money.format(it.avgProfit)}€ (${it.count})",fontSize=11.sp,color=SoulMuted)}}},confirmButton={TextButton(onClick=onDismiss){Text("CERRAR",color=SoulAmber)}})}
private fun recipeMargin(vm:MainViewModel,r:Recipe):Double{
    val products=vm.products.value
    fun cost(list:List<RecipeProduct>)=list.sumOf{rp->products.firstOrNull{it.id==rp.productId}?.let{productCostFor(it)*rp.quantity}?:0.0}
    val total=if(r.type=="dynamic"){
        val fixed=cost(r.fixedProducts)
        val dynamic=r.dynamicProductGroups.mapIndexed{index,g->
            val selected=r.defaultSelections[index.toString()]
            products.firstOrNull{it.id==selected}?.let{productCostFor(it)*g.quantity}?:0.0
        }.sum()
        fixed+dynamic
    }else cost(r.products)
    return if(r.sellingPrice<=0.0)0.0 else (r.sellingPrice-total)/r.sellingPrice*100.0
}

@Composable private fun CostsDialog(costs:List<FixedCost>,onAdd:(String,Double,String)->Unit,onDelete:(String)->Unit,onDismiss:()->Unit){var d by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var cat by remember{mutableStateOf("other")};AlertDialog(onDismissRequest=onDismiss,title={Text("ESTRUCTURA · Costes Fijos",fontWeight=FontWeight.Black)},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){Text("Define tus facturas y gastos fijos para calcular el beneficio real.",fontSize=10.sp,color=SoulMuted);Text("Total Gastos: ${money.format(costs.sumOf{it.amount})}€",fontSize=18.sp,fontWeight=FontWeight.Black,color=SoulAmber);SimpleField("Descripción",d){d=it};NumericField("Importe",amount){amount=it};SelectionMenu(cat,listOf("rent","salaries","utilities","marketing","other")){cat=it};ActionButton("AÑADIR GASTO",{if(d.isNotBlank()){onAdd(d,ParsingUtils.parseNumber(amount),cat);d="";amount=""}});costs.forEach{c->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("${c.description} — ${money.format(c.amount)}€",modifier=Modifier.weight(1f),fontSize=11.sp);Text("×",color=SoulRed,modifier=Modifier.clickable{onDelete(c.id)}.padding(6.dp))}}}},confirmButton={TextButton(onClick=onDismiss){Text("CERRAR",color=SoulAmber)}})}

@Composable private fun ObjectivesDialog(objectives:List<MarketingObjective>,onAdd:(String,Double,String,String)->Unit,onDelete:(MarketingObjective)->Unit,onDismiss:()->Unit){var d by remember{mutableStateOf("")};var value by remember{mutableStateOf("")};var type by remember{mutableStateOf("increase_sales")};var tf by remember{mutableStateOf("Mensual")};AlertDialog(onDismissRequest=onDismiss,title={Text("Objetivos de Marketing",fontWeight=FontWeight.Black)},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){SimpleField("Descripción",d){d=it};NumericField("Objetivo (%)",value){value=it};SelectionMenu(type,listOf("increase_sales","reduce_cost","improve_margin","other")){type=it};SelectionMenu(tf,listOf("Semanal","Mensual","Anual")){tf=it};ActionButton("CONFIRMAR OBJETIVO",{if(d.isNotBlank()){onAdd(d,ParsingUtils.parseNumber(value),type,tf);d="";value=""}});HorizontalDivider(color=SoulBorder);objectives.forEach{o->Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(o.description,fontWeight=FontWeight.Bold,fontSize=11.sp);Text("${o.timeframe} · ${o.targetValue}%",color=SoulMuted,fontSize=9.sp)};Text("×",color=SoulRed,modifier=Modifier.clickable{onDelete(o)}.padding(6.dp))}}}},confirmButton={TextButton(onClick=onDismiss){Text("CERRAR",color=SoulAmber)}})}

@Composable private fun SettingsDialog(vm:MainViewModel,onDismiss:()->Unit,onExport:()->Unit,onImport:()->Unit){var remote by remember{mutableStateOf(vm.isRemoteAi())};var url by remember{mutableStateOf("https://api.openai.com/v1/chat/completions")};var key by remember{mutableStateOf("")};var model by remember{mutableStateOf("gpt-4o-mini")};AlertDialog(onDismissRequest=onDismiss,title={Text("Ajustes · Gestión Soul",fontWeight=FontWeight.Black)},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp)){Text(if(remote)"IA remota" else"IA local",color=SoulAmber,fontWeight=FontWeight.Black);if(!remote){Text(vm.localAiLabel(),fontSize=10.sp,color=SoulMuted)};Row(Modifier.fillMaxWidth(),verticalAlignment=Alignment.CenterVertically){Text("Usar API externa",modifier=Modifier.weight(1f));Switch(remote,{remote=it;if(!it)vm.useLocalAi()})};if(remote){SimpleField("Base URL",url){url=it};SimpleField("API Key",key){key=it};SimpleField("Modelo",model){model=it};ActionButton("GUARDAR API",{vm.saveRemoteAi(url,key,model)})};Text("La base de datos es local y la IA local no requiere API.",fontSize=10.sp,color=SoulMuted);ActionButton("EXPORTAR BACKUP JSON",onExport,false);ActionButton("IMPORTAR BACKUP JSON",onImport,false)}},confirmButton={TextButton(onClick=onDismiss){Text("CERRAR",color=SoulAmber)}})}

@Composable private fun InvoiceReviewDialog(items:List<InvoiceLine>,onUpdate:(InvoiceLine)->Unit,onDelete:(String)->Unit,onConfirm:()->Unit,onDismiss:()->Unit){
    var editing by remember(items){ mutableStateOf<InvoiceLine?>(null) }
    AlertDialog(
        onDismissRequest=onDismiss,
        title={Text("Revisar factura",fontWeight=FontWeight.Black)},
        text={Column(Modifier.heightIn(max=520.dp).verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(8.dp)){
            Text("Revisa los datos antes de incorporarlos a la base local.",fontSize=10.sp,color=SoulMuted)
            if(items.isEmpty()) Text("No se detectaron líneas de producto.",color=SoulRed)
            items.forEach { line ->
                Card(colors=CardDefaults.cardColors(containerColor=SoulPanel2),shape=RoundedCornerShape(12.dp)){
                    Column(Modifier.padding(10.dp),verticalArrangement=Arrangement.spacedBy(5.dp)){
                        Text(line.description,fontWeight=FontWeight.Bold)
                        Text("${money.format(line.unitPrice)} € · Dto. ${money.format(line.discount)}% · IVA ${money.format(line.vat)}%",fontSize=10.sp,color=SoulMuted)
                        Text(if(line.existingProductId!=null) "Coincidencia con producto existente" else "Producto nuevo",fontSize=9.sp,color=if(line.existingProductId!=null) SoulGreen else SoulAmber)
                        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){
                            TextButton(onClick={editing=line}){Text("EDITAR",color=SoulAmber)}
                            TextButton(onClick={onDelete(line.key)}){Text("ELIMINAR",color=SoulRed)}
                        }
                    }
                }
            }
        }},
        confirmButton={Button(onClick=onConfirm,enabled=items.isNotEmpty(),colors=ButtonDefaults.buttonColors(containerColor=SoulAmber,contentColor=Color.Black)){Text("AÑADIR / ACTUALIZAR")}},
        dismissButton={TextButton(onClick=onDismiss){Text("CANCELAR",color=SoulMuted)}}
    )
    editing?.let { line ->
        InvoiceLineEditor(line,onSave={onUpdate(it);editing=null},onDismiss={editing=null})
    }
}

@Composable private fun InvoiceLineEditor(line:InvoiceLine,onSave:(InvoiceLine)->Unit,onDismiss:()->Unit){var d by remember(line.key){mutableStateOf(line.description)};var price by remember(line.key){mutableStateOf(line.unitPrice.toString())};var disc by remember(line.key){mutableStateOf(line.discount.toString())};var vat by remember(line.key){mutableStateOf(line.vat.toString())};AlertDialog(onDismissRequest=onDismiss,title={Text("Editar línea",fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){SimpleField("Descripción",d){d=it};NumericField("Costo Unit.",price){price=it};NumericField("Dto. (%)",disc){disc=it};NumericField("IVA (%)",vat){vat=it}}},confirmButton={TextButton(onClick={onSave(line.copy(description=d.trim(),unitPrice=ParsingUtils.parseNumber(price),discount=ParsingUtils.parseNumber(disc),vat=ParsingUtils.parseNumber(vat)))}){Text("GUARDAR",color=SoulAmber)}},dismissButton={TextButton(onClick=onDismiss){Text("CANCELAR",color=SoulMuted)}})}

@Composable private fun TextResultDialog(title:String,text:String,onDismiss:()->Unit,onUse:(()->Unit)?=null){val clipboard=LocalClipboardManager.current;AlertDialog(onDismissRequest=onDismiss,title={Text(title,fontWeight=FontWeight.Black)},text={Column(verticalArrangement=Arrangement.spacedBy(8.dp)){Box(Modifier.fillMaxWidth().height(350.dp).clip(RoundedCornerShape(10.dp)).background(SoulPanel2).verticalScroll(rememberScrollState()).padding(10.dp)){Text(text,fontSize=10.sp,color=SoulText)};ActionButton("COPIAR TEXTO",{clipboard.setText(AnnotatedString(text))},false)}},confirmButton={if(onUse!=null)TextButton(onClick=onUse){Text("USAR / PROCESAR",color=SoulAmber)};TextButton(onClick=onDismiss){Text("CERRAR",color=SoulMuted)}})}
@Composable private fun ConfirmDialog(title:String,text:String,onCancel:()->Unit,onConfirm:()->Unit){AlertDialog(onDismissRequest=onCancel,title={Text(title,fontWeight=FontWeight.Black)},text={Text(text,color=SoulText)},confirmButton={Button(onClick=onConfirm,colors=ButtonDefaults.buttonColors(containerColor=SoulRed,contentColor=Color.Black)){Text("ELIMINAR")}},dismissButton={TextButton(onClick=onCancel){Text("CANCELAR",color=SoulMuted)}})}

private fun loadBitmap(context: Context,uri: Uri):Bitmap?=try{context.contentResolver.openInputStream(uri)?.use{android.graphics.BitmapFactory.decodeStream(it)}}catch(_:Exception){null}
