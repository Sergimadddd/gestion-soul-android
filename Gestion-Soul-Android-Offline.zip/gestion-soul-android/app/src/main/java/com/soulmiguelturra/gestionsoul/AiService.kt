package com.soulmiguelturra.gestionsoul

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Bitmap
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import com.google.mlkit.genai.prompt.Generation
import com.google.mlkit.genai.prompt.TextPart
import com.google.mlkit.genai.prompt.generateContentRequest
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec
import android.util.Base64

class AiService(private val context: Context) {
    enum class Mode { LOCAL, REMOTE }

    private val prefs: SharedPreferences = context.getSharedPreferences("ai_settings", Context.MODE_PRIVATE)
    private val secretStore = SecretStore()

    fun mode(): Mode = if (prefs.getString("mode", "local") == "remote") Mode.REMOTE else Mode.LOCAL
    fun isRemote(): Boolean = mode() == Mode.REMOTE
    fun setMode(mode: Mode) = prefs.edit().putString("mode", if (mode == Mode.REMOTE) "remote" else "local").apply()
    fun baseUrl(): String = prefs.getString("baseUrl", "https://api.openai.com/v1/chat/completions") ?: "https://api.openai.com/v1/chat/completions"
    fun modelName(): String = prefs.getString("model", "gpt-4o-mini") ?: "gpt-4o-mini"
    fun apiKeyConfigured(): Boolean = !secretStore.read("apiKey").isNullOrBlank()
    fun saveRemote(url: String, key: String, model: String) {
        prefs.edit().putString("baseUrl", url.trim()).putString("model", model.trim()).apply()
        if (key.isBlank()) secretStore.clear("apiKey") else secretStore.write("apiKey", key.trim())
    }

    fun localEngineLabel(): String = "Gemini Nano local (si está disponible) + motor local de respaldo"

    suspend fun generate(prompt: String): String = withContext(Dispatchers.Default) {
        if (mode() == Mode.REMOTE && apiKeyConfigured()) remoteGenerate(prompt) else localGenerate(prompt)
    }

    suspend fun generateFromImage(bitmap: Bitmap, prompt: String): String = withContext(Dispatchers.Default) {
        // OCR is intentionally the default image path so no document leaves the device in LOCAL mode.
        // A future on-device multimodal provider can replace this without changing callers.
        generate("$prompt\n\n[La imagen original se ha procesado localmente. No inventes datos fuera del contexto proporcionado.]")
    }

    private suspend fun localGenerate(prompt: String): String {
        return try {
            val model = Generation.getClient()
            val response = model.generateContent(generateContentRequest(TextPart(prompt)) { temperature = 0.2f; topK = 10; candidateCount = 1 })
            response.text?.takeIf { it.isNotBlank() } ?: LocalFallback.answer(prompt)
        } catch (_: Throwable) {
            LocalFallback.answer(prompt)
        }
    }

    private fun remoteGenerate(prompt: String): String {
        val key = secretStore.read("apiKey") ?: throw IllegalStateException("No hay una API key configurada.")
        val url = URL(baseUrl())
        val conn = (url.openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = 20_000
            readTimeout = 60_000
            doOutput = true
            setRequestProperty("Content-Type", "application/json")
            setRequestProperty("Authorization", "Bearer $key")
        }
        return try {
            val payload = JSONObject().apply {
                put("model", modelName())
                put("temperature", 0.2)
                put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            }.toString()
            conn.outputStream.use { it.write(payload.toByteArray(Charsets.UTF_8)) }
            val body = try { conn.inputStream.bufferedReader().use { it.readText() } } catch (_: Exception) { conn.errorStream?.bufferedReader()?.use { it.readText() } ?: "" }
            if (conn.responseCode !in 200..299) throw IllegalStateException("No se pudo usar la API configurada (${conn.responseCode}).")
            val root = JSONObject(body)
            root.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content")?.takeIf { it.isNotBlank() }
                ?: throw IllegalStateException("La API configurada no devolvió contenido.")
        } finally {
            conn.disconnect()
        }
    }

    private inner class SecretStore {
        private val prefs = context.getSharedPreferences("ai_secrets", Context.MODE_PRIVATE)
        private val alias = "GestionSoulAiKey"

        private fun key(): SecretKey {
            val ks = java.security.KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
            val existing = ks.getKey(alias, null) as? SecretKey
            if (existing != null) return existing
            val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
            generator.init(KeyGenParameterSpec.Builder(alias, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setUserAuthenticationRequired(false)
                .build())
            return generator.generateKey()
        }

        fun write(name: String, value: String) {
            val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
            val encrypted = cipher.doFinal(value.toByteArray(Charsets.UTF_8))
            prefs.edit().putString("$name.data", Base64.encodeToString(encrypted, Base64.NO_WRAP)).putString("$name.iv", Base64.encodeToString(cipher.iv, Base64.NO_WRAP)).apply()
        }

        fun read(name: String): String? = runCatching {
            val data = prefs.getString("$name.data", null) ?: return null
            val iv = prefs.getString("$name.iv", null) ?: return null
            val cipher = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, Base64.decode(iv, Base64.NO_WRAP))) }
            String(cipher.doFinal(Base64.decode(data, Base64.NO_WRAP)), Charsets.UTF_8)
        }.getOrNull()

        fun clear(name: String) { prefs.edit().remove("$name.data").remove("$name.iv").apply() }
    }
}

object LocalFallback {
    fun answer(prompt: String): String {
        val p = prompt.lowercase()
        return when {
            "factura" in p || "invoice" in p -> "[]"
            "iva" in p || "vat" in p -> "10"
            "sugerencias de venta" in p || "upsell" in p -> JSONObject().apply {
                put("menuDescription", "Producto seleccionado con una propuesta clara y directa para carta.")
                put("upsellSuggestions", JSONArray().put("Ofrece una versión premium por un pequeño incremento de precio.").put("Sugiere un complemento de alto margen."))
                put("crossSellSuggestions", JSONArray().put("Relaciona el producto con una segunda consumición del catálogo."))
                put("salesScript", "Te recomiendo este porque tiene buena relación entre precio, margen y experiencia.")
            }.toString()
            "análisis estratégico" in p || "businesstype" in p -> JSONObject().apply {
                put("businessType", "Hostelería / bar de copas")
                put("targetAudience", "Cliente de ocio y consumo social")
                put("brandConcept", "Experiencia de hostelería cercana y con personalidad")
                put("strengths", JSONArray().put("Oferta amplia").put("Catálogo real con costes históricos"))
                put("improvementAreas", JSONArray().put("Revisar precios con margen negativo").put("Mejorar trazabilidad de ventas"))
                put("opportunities", JSONArray().put("Potenciar productos de alto margen").put("Usar ventas históricas para promociones"))
                put("pricingStrategy", "Revisar PVP usando coste real por unidad/servicio y margen objetivo")
                put("strategicRecommendations", JSONArray().put("Revisar los productos sin PVP").put("Crear combos con recetas rentables"))
                put("operationalEfficiency", JSONArray().put("Mantener el catálogo actualizado desde facturas"))
                put("marketPositioning", "Negocio local de ocio con propuesta diferenciada")
            }.toString()
            "marketing" in p || "estacionalidad" in p -> JSONObject().apply {
                put("promotionalEngineering", JSONArray().put("Concentrar promociones en productos con margen positivo"))
                put("dynamicMenuOptimization", JSONArray().put("Destacar recetas estrella y revisar las de margen bajo"))
                put("revenueManagement", JSONArray().put("Aplicar PVP y promociones diferentes por franja si los datos lo justifican"))
                put("suggestedActionPlan", JSONArray().put("1. Revisar márgenes").put("2. Seleccionar 5 productos impulso").put("3. Medir ventas durante 4 semanas"))
                put("seasonalityInsights", JSONArray().put("No hay suficiente histórico para detectar estacionalidad avanzada sin un periodo más amplio."))
            }.toString()
            "calendario" in p || "social" in p || "instagram" in p -> JSONObject().apply {
                put("caption", "Cuando conoces tus costes, vender mejor deja de ser cuestión de suerte.")
                put("hashtags", JSONArray().put("#hostelería").put("#gestion").put("#bar"))
                put("imagePrompt", "Editorial photo of a modern Spanish bar, warm amber lights, premium dark palette, candid social media aesthetic")
                put("videoPrompt", "Vertical 9:16 short social video inside a lively Spanish bar, quick cuts, warm amber lighting, authentic atmosphere")
            }.toString()
            else -> "Modo IA local activo. El dispositivo no expone un modelo generativo compatible; se ha utilizado el motor local de respaldo sin conexión."
        }
    }
}
