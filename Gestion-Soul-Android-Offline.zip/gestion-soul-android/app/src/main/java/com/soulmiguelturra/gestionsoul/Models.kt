package com.soulmiguelturra.gestionsoul

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

data class PriceHistory(
    val date: String,
    val pricePerUnit: Double,
    val priceWithVat: Double = 0.0,
    val pricePerServing: Double = 0.0
)

data class Product(
    val id: String = UUID.randomUUID().toString(),
    val description: String,
    val cost: Double,
    val discount: Double,
    val vat: Double,
    val unitPrice: Double,
    val servingsPerUnit: Double,
    val sellingPrice: Double,
    val profitAmount: Double,
    val profitMargin: Double,
    val category: String = "Sin Categoría",
    val supplierCategory: String = "Sin Categoría de Proveedor",
    val supplierId: String? = null,
    val priceHistory: List<PriceHistory> = emptyList()
)

data class Supplier(
    val id: String,
    val name: String,
    val description: String = "",
    val phone: String? = null
)

data class RecipeProduct(val productId: String, val quantity: Double)
data class DynamicProductGroup(val categoryId: String, val quantity: Double, val id: String = UUID.randomUUID().toString())

data class SalesSuggestion(
    val menuDescription: String,
    val upsellSuggestions: List<String>,
    val crossSellSuggestions: List<String>,
    val salesScript: String
)

data class Recipe(
    val id: String = UUID.randomUUID().toString(),
    val description: String,
    val sellingPrice: Double,
    val category: String = "Otros",
    val type: String = "simple",
    val products: List<RecipeProduct> = emptyList(),
    val fixedProducts: List<RecipeProduct> = emptyList(),
    val dynamicProductGroups: List<DynamicProductGroup> = emptyList(),
    val defaultSelections: Map<String, String> = emptyMap(),
    val salesSuggestion: SalesSuggestion? = null
)

data class FixedCost(val id: String, val description: String, val amount: Double, val category: String)
data class SaleEntry(val productName: String, val quantity: Double, val totalRevenue: Double, val date: String)

data class MarketingObjective(
    val id: String,
    val description: String,
    val targetValue: Double,
    val type: String,
    val timeframe: String,
    val createdAt: String,
    val status: String
)

data class SocialPost(
    val id: String,
    val platform: String,
    val caption: String,
    val hashtags: List<String>,
    val imagePrompt: String?,
    val videoPrompt: String?,
    val status: String,
    val scheduledDate: String?,
    val marketingObjectiveId: String?
)

data class BusinessAnalysis(
    val businessType: String,
    val targetAudience: String,
    val brandConcept: String,
    val strengths: List<String>,
    val improvementAreas: List<String>,
    val opportunities: List<String>,
    val pricingStrategy: String,
    val strategicRecommendations: List<String>,
    val operationalEfficiency: List<String>,
    val marketPositioning: String
)

data class MarketingStrategy(
    val promotionalEngineering: List<String>,
    val dynamicMenuOptimization: List<String>,
    val revenueManagement: List<String>,
    val suggestedActionPlan: List<String>,
    val seasonalityInsights: List<String>
)

data class BrandManual(
    val id: String,
    val fileName: String,
    val content: String,
    val uploadedAt: String,
    val toneOfVoice: String?,
    val targetAudience: String?,
    val visualIdentity: String?,
    val brandPillars: List<String>
)

data class Category(val id: String, val name: String, val supplierId: String? = null)
data class InvoiceLine(
    val key: String = UUID.randomUUID().toString(),
    val description: String,
    val unitPrice: Double,
    val discount: Double = 0.0,
    val vat: Double = 10.0,
    val servingsPerUnit: Double = 1.0,
    val category: String = "Sin Categoría",
    val supplierId: String? = null,
    val supplierCategory: String = "Sin Categoría de Proveedor",
    val existingProductId: String? = null
)

data class UsageEntry(
    val id: String,
    val description: String,
    val model: String,
    val inputTokens: Int,
    val outputTokens: Int,
    val cost: Double,
    val type: String,
    val timestamp: String
)

data class DashboardRow(val category: String, val avgProfit: Double, val count: Int)

data class BackupBundle(
    val products: List<Product>,
    val recipes: List<Recipe>,
    val suppliers: List<Supplier>,
    val categories: List<Category>,
    val recipeCategories: List<Category>,
    val supplierCategories: List<Category>,
    val fixedCosts: List<FixedCost>,
    val salesHistory: List<SaleEntry>,
    val objectives: List<MarketingObjective>,
    val posts: List<SocialPost>,
    val brandManual: BrandManual?,
    val businessAnalysis: BusinessAnalysis?,
    val marketingStrategy: MarketingStrategy?,
    val usageHistory: List<UsageEntry> = emptyList()
)

fun JSONObject.optDoubleSafe(key: String, default: Double = 0.0): Double =
    if (isNull(key)) default else optDouble(key, default)

fun JSONObject.stringList(key: String): List<String> {
    val arr = optJSONArray(key) ?: return emptyList()
    return buildList { for (i in 0 until arr.length()) add(arr.optString(i)) }
}

fun List<String>.toJsonArray(): String = JSONArray(this).toString()
