package com.soulmiguelturra.gestionsoul

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor

import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.suspendCancellableCoroutine
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileOutputStream
import java.io.FileInputStream
import java.text.Normalizer
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object OcrService {
    suspend fun recognize(bitmap: Bitmap): String = suspendCancellableCoroutine { cont ->
        val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result -> recognizer.close(); if (cont.isActive) cont.resume(result.text) }
            .addOnFailureListener { e -> recognizer.close(); if (cont.isActive) cont.resumeWithException(e) }
    }
}

object PdfOcrService {
    suspend fun extractText(context: Context, bytes: ByteArray): String = withContext(Dispatchers.Default) {
        if (bytes.isEmpty()) return@withContext ""
        val file = File.createTempFile("soul-pdf-", ".pdf", context.cacheDir)
        try {
            FileOutputStream(file).use { it.write(bytes) }
            val descriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY)
            try {
                val renderer = PdfRenderer(descriptor)
                try {
                    buildString {
                        for (pageIndex in 0 until renderer.pageCount) {
                            val page = renderer.openPage(pageIndex)
                            try {
                                val width = (page.width * 1.5f).toInt().coerceAtMost(2200)
                                val height = (page.height * 1.5f).toInt().coerceAtMost(3200)
                                val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
                                try {
                                    bitmap.eraseColor(Color.WHITE)
                                    page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                    val text = OcrService.recognize(bitmap)
                                    if (text.isNotBlank()) append("\n--- Página ${pageIndex + 1} ---\n").append(text)
                                } finally {
                                    bitmap.recycle()
                                }
                            } finally {
                                page.close()
                            }
                        }
                    }
                } finally {
                    renderer.close()
                }
            } finally {
                descriptor.close()
            }
        } finally { file.delete() }
    }
}

object DocumentTextExtractor {
    fun fromBytes(name: String, bytes: ByteArray): String {
        val lower=name.lowercase()
        return when {
            lower.endsWith(".txt") || lower.endsWith(".md") || lower.endsWith(".csv") -> bytes.toString(Charsets.UTF_8)
            lower.endsWith(".json") -> JSONObject(bytes.toString(Charsets.UTF_8)).toString(2)
            lower.endsWith(".docx") || lower.endsWith(".xlsx") -> extractZipXml(bytes)
            else -> bytes.toString(Charsets.UTF_8)
        }
    }
    private fun extractZipXml(bytes: ByteArray): String {
        val sb=StringBuilder()
        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            var e:ZipEntry?=zis.nextEntry
            while(e!=null){
                if(!e.isDirectory && (e.name.endsWith(".xml") || e.name.endsWith(".rels"))) {
                    val raw=zis.readBytes().toString(Charsets.UTF_8)
                    val cleaned=raw.replace(Regex("<[^>]+>"), " ").replace("&amp;","&").replace("&lt;","<").replace("&gt;",">")
                    sb.append(' ').append(cleaned)
                }
                e=zis.nextEntry
            }
        }
        return sb.toString().replace(Regex("\\s+")," ").trim()
    }
}

object ParsingUtils {
    fun normalize(s:String):String=Normalizer.normalize(s.lowercase(),Normalizer.Form.NFD).replace("\\p{InCombiningDiacriticalMarks}+".toRegex(),"").replace("[^a-z0-9 ]".toRegex()," ").replace(Regex("\\s+")," ").trim()
    fun parseNumber(raw:String?):Double { if(raw==null)return 0.0;var s=raw.replace("€","").replace("%","").trim();if(s.count{it==','}==1 && s.count{it=='.'}>1)s=s.replace(".","").replace(',', '.');else if(s.count{it==','}==1 && s.count{it=='.'}==0)s=s.replace(',','.');else s=s.replace(",","");return s.toDoubleOrNull()?:0.0 }
}
