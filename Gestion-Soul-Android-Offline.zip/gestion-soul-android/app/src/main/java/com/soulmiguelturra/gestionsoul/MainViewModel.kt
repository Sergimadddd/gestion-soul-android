package com.soulmiguelturra.gestionsoul

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.UUID

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val db = SoulDatabase(app)
    private val ai = AiService(app)

    private val _products = MutableStateFlow<List<Product>>(emptyList())
    val products: StateFlow<List<Product>> = _products.asStateFlow()
    private val _recipes = MutableStateFlow<List<Recipe>>(emptyList())
    val recipes: StateFlow<List<Recipe>> = _recipes.asStateFlow()
    private val _suppliers = MutableStateFlow<List<Supplier>>(emptyList())
    val suppliers: StateFlow<List<Supplier>> = _suppliers.asStateFlow()
    private val _categories = MutableStateFlow<List<Category>>(emptyList())
    val categories: StateFlow<List<Category>> = _categories.asStateFlow()
    private val _recipeCategories = MutableStateFlow<List<Category>>(emptyList())
    val recipeCategories: StateFlow<List<Category>> = _recipeCategories.asStateFlow()
    private val _supplierCategories = MutableStateFlow<List<Category>>(emptyList())
    val supplierCategories: StateFlow<List<Category>> = _supplierCategories.asStateFlow()
    private val _fixedCosts = MutableStateFlow<List<FixedCost>>(emptyList())
    val fixedCosts: StateFlow<List<FixedCost>> = _fixedCosts.asStateFlow()
    private val _sales = MutableStateFlow<List<SaleEntry>>(emptyList())
    val sales: StateFlow<List<SaleEntry>> = _sales.asStateFlow()
    private val _objectives = MutableStateFlow<List<MarketingObjective>>(emptyList())
    val objectives: StateFlow<List<MarketingObjective>> = _objectives.asStateFlow()
    private val _posts = MutableStateFlow<List<SocialPost>>(emptyList())
    val posts: StateFlow<List<SocialPost>> = _posts.asStateFlow()
    private val _brandManual = MutableStateFlow<BrandManual?>(null)
    val brandManual: StateFlow<BrandManual?> = _brandManual.asStateFlow()
    private val _businessAnalysis = MutableStateFlow<BusinessAnalysis?>(null)
    val businessAnalysis: StateFlow<BusinessAnalysis?> = _businessAnalysis.asStateFlow()
    private val _marketingStrategy = MutableStateFlow<MarketingStrategy?>(null)
    val marketingStrategy: StateFlow<MarketingStrategy?> = _marketingStrategy.asStateFlow()

    private val _search = MutableStateFlow("")
    val search: StateFlow<String> = _search.asStateFlow()
    private val _recipeSearch = MutableStateFlow("")
    val recipeSearch: StateFlow<String> = _recipeSearch.asStateFlow()
    private val _busy = MutableStateFlow(false)
    val busy: StateFlow<Boolean> = _busy.asStateFlow()
    private val _message = MutableStateFlow<String?>(null)
    val message: StateFlow<String?> = _message.asStateFlow()
    private val _invoiceResult = MutableStateFlow<String?>(null)
    val invoiceResult: StateFlow<String?> = _invoiceResult.asStateFlow()
    private val _invoiceItems = MutableStateFlow<List<InvoiceLine>>(emptyList())
    val invoiceItems: StateFlow<List<InvoiceLine>> = _invoiceItems.asStateFlow()

    init { reload() }

    fun clearMessage() { _message.value = null }
    fun setSearch(value: String) { _search.value = value }
    fun setRecipeSearch(value: String) { _recipeSearch.value = value }

    fun reload() {
        viewModelScope.launch(Dispatchers.IO) {
            _products.value = db.getProducts()
            _recipes.value = db.getRecipes()
            _suppliers.value = db.getSuppliers()
            _categories.value = db.getCategories()
            _recipeCategories.value = db.getRecipeCategories()
            _supplierCategories.value = db.getSupplierCategories()
            _fixedCosts.value = db.getFixedCosts()
            _sales.value = db.getSales()
            _objectives.value = db.getObjectives()
            _posts.value = db.getPosts()
            _brandManual.value = db.getBrandManual()
            _businessAnalysis.value = db.getBusinessAnalysis()
            _marketingStrategy.value = db.getMarketingStrategy()
        }
    }

    val filteredProducts: List<Product>
        get() = products.value.filter { ParsingUtils.normalize(it.description).contains(ParsingUtils.normalize(search.value)) }

    val filteredRecipes: List<Recipe>
        get() = recipes.value.filter { ParsingUtils.normalize(it.description).contains(ParsingUtils.normalize(recipeSearch.value)) }

    fun saveProduct(
        existing: Product?, description: String, category: String, supplierId: String?, supplierCategory: String,
        cost: Double, discount: Double, vat: Double, servings: Double, sellingPrice: Double
    ) {
        val safeServings = servings.coerceAtLeast(1.0)
        val unit = cost * (1.0 - discount / 100.0)
        val sellingWithoutVat = sellingPrice / 1.10
        val profit = sellingWithoutVat - unit
        val margin = if (unit != 0.0) profit / unit * 100.0 else 0.0
        val history = existing?.priceHistory?.toMutableList() ?: mutableListOf()
        val old = existing?.unitPrice
        if (old == null || kotlin.math.abs(old - unit) > 0.000001 || existing?.vat != vat) {
            history += PriceHistory(
                date = Instant.now().toString(),
                pricePerUnit = unit,
                priceWithVat = unit * (1.0 + vat / 100.0),
                pricePerServing = unit * (1.0 + vat / 100.0) / safeServings
            )
            while (history.size > 10) history.removeAt(0)
        }
        val product = Product(
            id = existing?.id ?: UUID.randomUUID().toString(),
            description = description,
            cost = cost,
            discount = discount,
            vat = vat,
            unitPrice = unit,
            servingsPerUnit = safeServings,
            sellingPrice = sellingPrice,
            profitAmount = profit,
            profitMargin = margin,
            category = category.ifBlank { "Sin Categoría" },
            supplierCategory = supplierCategory.ifBlank { "Sin Categoría de Proveedor" },
            supplierId = supplierId,
            priceHistory = history
        )
        viewModelScope.launch(Dispatchers.IO) {
            db.upsertProduct(product)
            reload()
            _message.value = if (existing == null) "Producto añadido." else "Producto actualizado."
        }
    }

    fun deleteProduct(id: String) = viewModelScope.launch(Dispatchers.IO) {
        db.deleteProduct(id)
        reload()
        _message.value = "Producto eliminado."
    }

    fun saveRecipe(
        existing: Recipe?, description: String, pvp: Double, category: String, type: String,
        products: List<RecipeProduct>, fixed: List<RecipeProduct>, groups: List<DynamicProductGroup>,
        selections: Map<String, String>, salesSuggestion: SalesSuggestion?
    ) {
        val recipe = Recipe(
            id = existing?.id ?: UUID.randomUUID().toString(), description = description, sellingPrice = pvp,
            category = category, type = type, products = products, fixedProducts = fixed,
            dynamicProductGroups = groups, defaultSelections = selections, salesSuggestion = salesSuggestion
        )
        viewModelScope.launch(Dispatchers.IO) {
            db.upsertRecipe(recipe)
            reload()
            _message.value = if (existing == null) "Receta creada." else "Receta actualizada."
        }
    }

    suspend fun generateSalesSuggestion(
        itemName: String, category: String, totalCost: Double, sellingPrice: Double
    ): SalesSuggestion {
        if (sellingPrice <= 0.0) throw IllegalArgumentException("Añade un PVP para generar sugerencias.")
        val prompt = """
            Genera sugerencias de venta para el producto/oferta "$itemName" de categoría "$category".
            Coste real estimado: ${"%.4f".format(java.util.Locale.US, totalCost)}€.
            PVP: ${"%.4f".format(java.util.Locale.US, sellingPrice)}€.
            Devuelve SOLO JSON con: menuDescription, upsellSuggestions[], crossSellSuggestions[], salesScript.
            El tono debe ser cercano, práctico y adecuado para hostelería española.
        """.trimIndent()
        val root = JSONObject(extractJsonObject(ai.generate(prompt)))
        return SalesSuggestion(
            menuDescription = root.optString("menuDescription", "Producto seleccionado con una propuesta clara y directa para carta."),
            upsellSuggestions = root.stringList("upsellSuggestions"),
            crossSellSuggestions = root.stringList("crossSellSuggestions"),
            salesScript = root.optString("salesScript", "Te recomiendo este porque tiene buena relación entre precio, margen y experiencia.")
        )
    }

    fun deleteRecipe(id: String) = viewModelScope.launch(Dispatchers.IO) {
        db.deleteRecipe(id)
        reload()
        _message.value = "Receta eliminada."
    }

    fun addCategory(type: String, name: String, supplierId: String? = null) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { db.addCategory(type, name, supplierId) }
                .onSuccess { reload(); _message.value = "Categoría añadida." }
                .onFailure { _message.value = it.message ?: "No se pudo añadir la categoría." }
        }
    }

    fun renameCategory(category: Category, type: String, newName: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { db.renameCategory(category, type, newName) }
                .onSuccess { reload(); _message.value = "Categoría actualizada." }
                .onFailure { _message.value = it.message ?: "No se pudo actualizar la categoría." }
        }
    }

    fun deleteCategory(category: Category, type: String) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { db.deleteCategory(category, type) }
                .onSuccess { reload(); _message.value = "Categoría eliminada. Los elementos asociados quedan sin categoría." }
                .onFailure { _message.value = it.message ?: "No se pudo eliminar la categoría." }
        }
    }

    fun saveSupplier(existing: Supplier?, name: String, description: String, phone: String) {
        val supplier = Supplier(existing?.id ?: UUID.randomUUID().toString(), name, description, phone.ifBlank { null })
        viewModelScope.launch(Dispatchers.IO) {
            db.upsertSupplier(supplier)
            reload()
            _message.value = "Proveedor guardado."
        }
    }

    fun deleteSupplier(id: String) = viewModelScope.launch(Dispatchers.IO) {
        db.deleteSupplier(id)
        reload()
        _message.value = "Proveedor eliminado."
    }

    fun addObjective(description: String, target: Double, type: String, timeframe: String) {
        val objective = MarketingObjective(UUID.randomUUID().toString(), description, target, type, timeframe, Instant.now().toString(), "active")
        viewModelScope.launch(Dispatchers.IO) {
            db.upsertObjective(objective)
            reload()
            _message.value = "Objetivo añadido."
        }
    }

    fun deleteObjective(id: String) = viewModelScope.launch(Dispatchers.IO) {
        db.deleteObjective(id)
        reload()
        _message.value = "Objetivo eliminado."
    }

    fun addFixedCost(description: String, amount: Double, category: String) {
        viewModelScope.launch(Dispatchers.IO) {
            val list = db.getFixedCosts().toMutableList()
            list += FixedCost(UUID.randomUUID().toString(), description, amount, category)
            db.replaceFixedCosts(list)
            reload()
            _message.value = "Gasto fijo añadido."
        }
    }

    fun deleteFixedCost(id: String) {
        viewModelScope.launch(Dispatchers.IO) {
            db.replaceFixedCosts(db.getFixedCosts().filterNot { it.id == id })
            reload()
            _message.value = "Gasto eliminado."
        }
    }

    fun saveSalesFromCsv(text: String): Int {
        val lines = text.lines().filter { it.isNotBlank() }
        if (lines.size < 2) return 0
        val separator = if (lines.first().count { it == ';' } >= lines.first().count { it == ',' }) ';' else ','
        fun cols(line: String) = line.split(separator).map { it.trim().trim('"') }
        val header = cols(lines.first()).map(ParsingUtils::normalize)
        fun indexOf(vararg names: String): Int {
            names.forEach { name -> header.indexOf(ParsingUtils.normalize(name)).takeIf { it >= 0 }?.let { return it } }
            return -1
        }
        val productIndex = indexOf("producto", "nombre", "descripción", "descripcion")
        val quantityIndex = indexOf("cantidad", "unidades", "qty")
        val revenueIndex = indexOf("total", "importe", "revenue")
        val dateIndex = indexOf("fecha", "date")
        if (productIndex < 0 || quantityIndex < 0 || revenueIndex < 0) {
            _message.value = "No se han encontrado columnas de Producto, Cantidad y Total en el archivo."
            return 0
        }
        val imported = buildList {
            lines.drop(1).forEach { line ->
                val c = cols(line)
                val maxIndex = maxOf(productIndex, quantityIndex, revenueIndex)
                if (c.size > maxIndex && c[productIndex].isNotBlank()) {
                    add(SaleEntry(c[productIndex], ParsingUtils.parseNumber(c[quantityIndex]), ParsingUtils.parseNumber(c[revenueIndex]), if (dateIndex >= 0 && c.size > dateIndex) c[dateIndex] else Instant.now().toString()))
                }
            }
        }
        viewModelScope.launch(Dispatchers.IO) {
            db.replaceSales(db.getSales() + imported)
            reload()
            _message.value = "${imported.size} registros de ventas importados."
        }
        return imported.size
    }

    fun exportBackup(): String = db.exportBackup()

    fun importBackup(text: String) {
        viewModelScope.launch(Dispatchers.IO) {
            _busy.value = true
            try {
                val result = db.replaceFromBackupJson(text)
                result.getOrThrow()
                reload()
                _message.value = "Backup restaurado correctamente. Se han reemplazado los datos locales."
            } catch (e: Exception) {
                _message.value = "No se pudo restaurar el backup: ${e.message ?: "archivo inválido"}"
            } finally {
                _busy.value = false
            }
        }
    }

    fun runBusinessAnalysis() {
        val p = products.value
        val r = recipes.value
        val costs = fixedCosts.value
        _busy.value = true
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val prompt = """
                    Realiza un análisis estratégico de un negocio hostelero basándote exclusivamente en estos datos.
                    No inventes cifras. Devuelve JSON con: businessType,targetAudience,brandConcept,strengths[],improvementAreas[],opportunities[],pricingStrategy,strategicRecommendations[],operationalEfficiency[],marketPositioning.
                    PRODUCTOS: ${p.take(120).joinToString(" | ") { "${it.description} coste ${it.unitPrice}€ margen ${it.profitMargin}%" }}
                    RECETAS: ${r.take(120).joinToString(" | ") { "${it.description} PVP ${it.sellingPrice}€" }}
                    COSTES FIJOS: ${costs.joinToString(" | ") { "${it.description} ${it.amount}€" }}
                """.trimIndent()
                val root = JSONObject(extractJsonObject(ai.generate(prompt)))
                val analysis = BusinessAnalysis(
                    root.optString("businessType", "Hostelería"), root.optString("targetAudience", "Cliente local"),
                    root.optString("brandConcept", "Experiencia de hostelería con personalidad"), root.stringList("strengths"),
                    root.stringList("improvementAreas"), root.stringList("opportunities"), root.optString("pricingStrategy"),
                    root.stringList("strategicRecommendations"), root.stringList("operationalEfficiency"), root.optString("marketPositioning")
                )
                db.setBusinessAnalysis(analysis)
                _businessAnalysis.value = analysis
                _message.value = "Análisis de negocio completado."
            } catch (e: Exception) {
                _message.value = "No se pudo completar el análisis avanzado: ${e.message ?: "error"}"
            } finally {
                _busy.value = false
            }
        }
    }

    fun generateMarketingStrategy() {
        _busy.value = true
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val prompt = "Genera estrategia de marketing para este negocio hostelero usando ventas, productos y recetas. Devuelve JSON con promotionalEngineering[],dynamicMenuOptimization[],revenueManagement[],suggestedActionPlan[],seasonalityInsights[]. Ventas: ${sales.value.take(180)}. Productos: ${products.value.take(100).map { "${it.description}/${it.profitMargin}" }}. Recetas: ${recipes.value.take(100).map { "${it.description}/${it.sellingPrice}" }}"
                val root = JSONObject(extractJsonObject(ai.generate(prompt)))
                val strategy = MarketingStrategy(root.stringList("promotionalEngineering"),root.stringList("dynamicMenuOptimization"),root.stringList("revenueManagement"),root.stringList("suggestedActionPlan"),root.stringList("seasonalityInsights"))
                db.setMarketingStrategy(strategy)
                _marketingStrategy.value = strategy
                _message.value = "Estrategia de marketing actualizada."
            } catch (e: Exception) {
                _message.value = "No se pudo generar la estrategia: ${e.message ?: "error"}"
            } finally {
                _busy.value = false
            }
        }
    }

    fun generateSocialIdea(objective: MarketingObjective?) {
        _busy.value = true
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val manualContext = brandManual.value?.content?.take(8000).orEmpty()
                val prompt = "Genera una idea de publicación para ${objective?.description ?: "captación y ventas"}. Devuelve JSON con caption,hashtags[],imagePrompt,videoPrompt. Usa el tono del manual de marca si existe. Datos de catálogo: ${products.value.take(40).joinToString(",") { it.description }}. Manual: $manualContext"
                val root = JSONObject(extractJsonObject(ai.generate(prompt)))
                val post = SocialPost(UUID.randomUUID().toString(), "instagram", root.optString("caption"), root.stringList("hashtags"), root.optString("imagePrompt", null), root.optString("videoPrompt", null), "draft", null, objective?.id)
                db.upsertPost(post)
                reload()
                _message.value = "Idea social creada."
            } catch (e: Exception) {
                _message.value = "No se pudo generar la idea: ${e.message ?: "error"}"
            } finally {
                _busy.value = false
            }
        }
    }

    fun saveBrandFromText(fileName: String, text: String) {
        val manual = BrandManual(
            UUID.randomUUID().toString(), fileName, text, Instant.now().toString(),
            "Cercano, inspirador, emocional, respetuoso, con picardía y vibración positiva",
            "Público local y de ocio", "Paleta oscura con acentos amber",
            listOf("Cercanía", "Autenticidad", "Calidad", "Pasión", "Innovación")
        )
        viewModelScope.launch(Dispatchers.IO) {
            db.upsertBrandManual(manual)
            reload()
            _message.value = "Manual de marca guardado localmente."
        }
    }

    fun saveRemoteAi(url: String, key: String, model: String) {
        ai.saveRemote(url, key, model)
        ai.setMode(AiService.Mode.REMOTE)
        _message.value = "Proveedor remoto configurado."
    }

    fun useLocalAi() {
        ai.setMode(AiService.Mode.LOCAL)
        _message.value = "IA local activada. Las funciones IA no usarán una API externa."
    }

    fun isRemoteAi(): Boolean = ai.mode() == AiService.Mode.REMOTE
    fun localAiLabel(): String = ai.localEngineLabel()
    fun remoteAiConfigured(): Boolean = ai.apiKeyConfigured()

    suspend fun ocr(bitmap: Bitmap): String = OcrService.recognize(bitmap)

    fun invoiceStructured(text: String) {
        viewModelScope.launch(Dispatchers.Default) {
            try {
                val prompt = "Extrae de esta factura solo líneas de producto. Devuelve JSON array con description,unitPrice,discount,vat. No inventes datos. Si falta IVA, utiliza 10 como valor por defecto editable. TEXTO: $text"
                val raw = ai.generate(prompt)
                _invoiceResult.value = raw
                _invoiceItems.value = parseInvoiceItems(raw)
                _message.value = "Factura procesada en modo ${if (ai.isRemote()) "API" else "local"}. Revisa los datos antes de añadirlos."
            } catch (e: Exception) {
                _message.value = "No se pudo procesar la factura: ${e.message ?: "error"}"
            }
        }
    }

    fun updateInvoiceItem(item: InvoiceLine) {
        _invoiceItems.value = _invoiceItems.value.map { if (it.key == item.key) item else it }
    }

    fun deleteInvoiceItem(key: String) { _invoiceItems.value = _invoiceItems.value.filterNot { it.key == key } }

    fun confirmInvoiceImport() {
        val items = _invoiceItems.value
        if (items.isEmpty()) { _message.value = "No hay líneas de factura para añadir."; return }
        viewModelScope.launch(Dispatchers.IO) {
            items.forEach { line ->
                val matched = line.existingProductId?.let(db::getProduct) ?: ProductMatcher.bestMatch(line.description, db.getProducts())
                val existing = matched
                val safeServings = line.servingsPerUnit.coerceAtLeast(1.0)
                val unit = line.unitPrice * (1.0 - line.discount / 100.0)
                val history = existing?.priceHistory?.toMutableList() ?: mutableListOf()
                val record = PriceHistory(Instant.now().toString(), unit, unit * (1.0 + line.vat / 100.0), unit * (1.0 + line.vat / 100.0) / safeServings)
                history += record
                while (history.size > 10) history.removeAt(0)
                val sellingPrice = existing?.sellingPrice ?: 0.0
                val profit = sellingPrice / 1.10 - unit
                val margin = if (unit > 0.0) profit / unit * 100.0 else 0.0
                db.upsertProduct(Product(existing?.id ?: UUID.randomUUID().toString(), line.description, line.unitPrice, line.discount, line.vat, unit, safeServings, sellingPrice, profit, margin, line.category, line.supplierCategory, line.supplierId, history))
            }
            reload()
            _invoiceItems.value = emptyList()
            _message.value = "${items.size} líneas añadidas/actualizadas en la base de datos local."
        }
    }

    fun clearInvoice() { _invoiceResult.value = null; _invoiceItems.value = emptyList() }

    private fun parseInvoiceItems(raw: String): List<InvoiceLine> {
        val arr = runCatching {
            val trimmed = raw.trim()
            when {
                trimmed.startsWith("[") -> JSONArray(trimmed)
                trimmed.startsWith("{") -> JSONObject(trimmed).optJSONArray("items") ?: JSONArray()
                else -> JSONArray()
            }
        }.getOrElse { return emptyList() }
        return buildList {
            for (i in 0 until arr.length()) {
                val o = arr.optJSONObject(i) ?: continue
                val description = o.optString("description").trim()
                if (description.isBlank()) continue
                val unitPrice = o.optDoubleSafe("unitPrice")
                val discount = o.optDoubleSafe("discount")
                val vat = if (o.isNull("vat")) 10.0 else o.optDoubleSafe("vat", 10.0)
                val match = ProductMatcher.bestMatch(description, products.value)
                add(InvoiceLine(description=description,unitPrice=unitPrice,discount=discount,vat=vat,existingProductId=match?.id,category=match?.category ?: "Sin Categoría",supplierId=match?.supplierId,supplierCategory=match?.supplierCategory ?: "Sin Categoría de Proveedor"))
            }
        }
    }

    fun productDashboard(): List<DashboardRow> = products.value.groupBy { it.category }
        .map { (category, list) -> DashboardRow(category, list.map { it.profitAmount }.averageOrZero(), list.size) }
        .sortedByDescending { it.avgProfit }

    private fun List<Double>.averageOrZero(): Double = if (isEmpty()) 0.0 else average()
    fun totalFixedCosts(): Double = fixedCosts.value.sumOf { it.amount }
    fun totalSales(): Double = sales.value.sumOf { it.totalRevenue }
    fun safetyMargin(): Double { val total = totalSales(); return if (total == 0.0) 0.0 else (1.0 - totalFixedCosts() / total) * 100.0 }
    fun breakEven(): Double = totalFixedCosts()

    private fun extractJsonObject(raw: String): String {
        val trimmed = raw.trim()
        val objectStart = trimmed.indexOf('{')
        val objectEnd = trimmed.lastIndexOf('}')
        if (objectStart >= 0 && objectEnd > objectStart) return trimmed.substring(objectStart, objectEnd + 1)
        val arrayStart = trimmed.indexOf('[')
        val arrayEnd = trimmed.lastIndexOf(']')
        if (arrayStart >= 0 && arrayEnd > arrayStart) return JSONObject().put("items", JSONArray(trimmed.substring(arrayStart, arrayEnd + 1))).toString()
        return trimmed
    }

    override fun onCleared() { db.close(); super.onCleared() }
}
