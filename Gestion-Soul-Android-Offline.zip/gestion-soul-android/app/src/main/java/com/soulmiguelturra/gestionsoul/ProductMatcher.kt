package com.soulmiguelturra.gestionsoul

/** Mirrors the original invoice matching strategy: normalization + token overlap + Levenshtein. */
object ProductMatcher {
    const val SIMILARITY_THRESHOLD = 0.8

    fun bestMatch(description: String, products: List<Product>): Product? {
        if (products.isEmpty()) return null
        val target = ParsingUtils.normalize(description)
        if (target.isBlank()) return null
        var best: Product? = null
        var bestScore = 0.0
        for (candidate in products) {
            val score = similarity(target, ParsingUtils.normalize(candidate.description))
            if (score > bestScore) {
                bestScore = score
                best = candidate
            }
        }
        return best?.takeIf { bestScore >= SIMILARITY_THRESHOLD }
    }

    fun similarity(a: String, b: String): Double {
        if (a == b) return 1.0
        if (a.isBlank() || b.isBlank()) return 0.0
        if (a.contains(b) || b.contains(a)) return 0.9
        val aTokens = a.split(' ').filter { it.isNotBlank() }.toSet()
        val bTokens = b.split(' ').filter { it.isNotBlank() }.toSet()
        val union = aTokens union bTokens
        val intersection = aTokens intersect bTokens
        val tokenScore = if (union.isEmpty()) 0.0 else intersection.size.toDouble() / union.size.toDouble()
        val lev = levenshtein(a, b)
        val levScore = 1.0 - lev.toDouble() / maxOf(a.length, b.length).coerceAtLeast(1)
        return maxOf(tokenScore, levScore)
    }

    private fun levenshtein(a: String, b: String): Int {
        if (a == b) return 0
        if (a.isEmpty()) return b.length
        if (b.isEmpty()) return a.length
        var prev = IntArray(b.length + 1) { it }
        var current = IntArray(b.length + 1)
        for (i in a.indices) {
            current[0] = i + 1
            for (j in b.indices) {
                val cost = if (a[i] == b[j]) 0 else 1
                current[j + 1] = minOf(
                    current[j] + 1,
                    prev[j + 1] + 1,
                    prev[j] + cost
                )
            }
            val temp = prev
            prev = current
            current = temp
        }
        return prev[b.length]
    }
}
