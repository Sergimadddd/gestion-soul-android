package com.soulmiguelturra.gestionsoul

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONArray
import org.json.JSONObject
import java.time.Instant
import java.util.UUID

class SoulDatabase(private val context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {

    companion object {
        private const val DB_NAME = "gestion_soul.db"
        private const val DB_VERSION = 3
        private const val JSON_ASSET = "initial_backup.json"
    }

    override fun onCreate(db: SQLiteDatabase) {
        createSchema(db)
        db.beginTransaction()
        try {
            importRoot(db, readAssetRoot())
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        if (oldVersion < 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS usage_history(id TEXT PRIMARY KEY, description TEXT, model TEXT, inputTokens INTEGER, outputTokens INTEGER, cost REAL, type TEXT, timestamp TEXT)")
        }
        if (oldVersion < 3) {
            runCatching { db.execSQL("ALTER TABLE recipes ADD COLUMN salesSuggestion TEXT") }
        }
    }

    private fun createSchema(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE IF NOT EXISTS products(id TEXT PRIMARY KEY, description TEXT NOT NULL, cost REAL, discount REAL, vat REAL, unitPrice REAL, servings REAL, sellingPrice REAL, profitAmount REAL, profitMargin REAL, category TEXT, supplierCategory TEXT, supplierId TEXT, history TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS suppliers(id TEXT PRIMARY KEY, name TEXT NOT NULL, description TEXT, phone TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS categories(id TEXT PRIMARY KEY, name TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS recipe_categories(id TEXT PRIMARY KEY, name TEXT NOT NULL)")
        db.execSQL("CREATE TABLE IF NOT EXISTS supplier_categories(id TEXT PRIMARY KEY, name TEXT NOT NULL, supplierId TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS recipes(id TEXT PRIMARY KEY, description TEXT NOT NULL, sellingPrice REAL, category TEXT, type TEXT, products TEXT, fixedProducts TEXT, dynamicGroups TEXT, defaultSelections TEXT, salesSuggestion TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS fixed_costs(id TEXT PRIMARY KEY, description TEXT, amount REAL, category TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS sales(id INTEGER PRIMARY KEY AUTOINCREMENT, productName TEXT, quantity REAL, totalRevenue REAL, date TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS objectives(id TEXT PRIMARY KEY, description TEXT, targetValue REAL, type TEXT, timeframe TEXT, createdAt TEXT, status TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS social_posts(id TEXT PRIMARY KEY, platform TEXT, caption TEXT, hashtags TEXT, imagePrompt TEXT, videoPrompt TEXT, status TEXT, scheduledDate TEXT, marketingObjectiveId TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS brand_manual(id TEXT PRIMARY KEY, fileName TEXT, content TEXT, uploadedAt TEXT, toneOfVoice TEXT, targetAudience TEXT, visualIdentity TEXT, brandPillars TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS business_analysis(id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS marketing_strategy(id INTEGER PRIMARY KEY CHECK(id=1), payload TEXT)")
        db.execSQL("CREATE TABLE IF NOT EXISTS usage_history(id TEXT PRIMARY KEY, description TEXT, model TEXT, inputTokens INTEGER, outputTokens INTEGER, cost REAL, type TEXT, timestamp TEXT)")
    }

    private fun readAssetRoot(): JSONObject {
        val text = context.assets.open(JSON_ASSET).bufferedReader().use { it.readText() }
        return JSONObject(text).optJSONObject("database") ?: JSONObject()
    }

    /** Replace all local data atomically with a validated backup. */
    fun replaceFromBackupJson(jsonText: String): Result<Unit> = runCatching {
        val root = JSONObject(jsonText).optJSONObject("database")
            ?: throw IllegalArgumentException("El archivo no contiene una base de datos Gestión Soul válida.")
        validateRoot(root)
        val db = writableDatabase
        db.beginTransaction()
        try {
            clearAll(db)
            importRoot(db, root)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun validateRoot(root: JSONObject) {
        val products = root.optJSONArray("products") ?: JSONArray()
        val recipes = root.optJSONArray("recipes") ?: JSONArray()
        products.forEachObject { require(it.optString("description").isNotBlank()) { "Hay un producto sin descripción." } }
        recipes.forEachObject { require(it.optString("description").isNotBlank()) { "Hay una receta sin descripción." } }
    }

    private fun clearAll(db: SQLiteDatabase) {
        listOf(
            "products", "suppliers", "categories", "recipe_categories", "supplier_categories", "recipes",
            "fixed_costs", "sales", "objectives", "social_posts", "brand_manual", "business_analysis",
            "marketing_strategy", "usage_history"
        ).forEach { db.delete(it, null, null) }
    }

    private fun importRoot(db: SQLiteDatabase, root: JSONObject) {
        
            root.optJSONArray("categories").insertCategoriesInto(db, "categories")
            root.optJSONArray("recipeCategories").insertCategoriesInto(db, "recipe_categories")
            root.optJSONArray("supplierProductCategories").forEachObject { o ->
                db.insertWithOnConflict("supplier_categories", null, contentValues {
                    put("id", o.optString("id", UUID.randomUUID().toString()))
                    put("name", o.optString("name"))
                    putNullable("supplierId", o.optString("supplierId", null))
                }, SQLiteDatabase.CONFLICT_REPLACE)
            }
            root.optJSONArray("suppliers").forEachObject { o ->
                db.insertWithOnConflict("suppliers", null, contentValues {
                    put("id", o.optString("id", UUID.randomUUID().toString()))
                    put("name", o.optString("name"))
                    put("description", o.optString("description"))
                    putNullable("phone", o.optString("phone", null))
                }, SQLiteDatabase.CONFLICT_REPLACE)
            }
            root.optJSONArray("products").forEachObject { insertProduct(db, parseProduct(it)) }
            root.optJSONArray("recipes").forEachObject { insertRecipe(db, parseRecipe(it)) }
            root.optJSONArray("fixedCosts").forEachObject { o ->
                db.insert("fixed_costs", null, contentValues {
                    put("id", o.optString("id", UUID.randomUUID().toString()))
                    put("description", o.optString("description"))
                    put("amount", o.optDoubleSafe("amount"))
                    put("category", o.optString("category", "other"))
                })
            }
            root.optJSONArray("salesHistory").forEachObject { o ->
                db.insert("sales", null, contentValues {
                    put("productName", o.optString("productName"))
                    put("quantity", o.optDoubleSafe("quantity"))
                    put("totalRevenue", o.optDoubleSafe("totalRevenue"))
                    put("date", o.optString("date"))
                })
            }
            root.optJSONArray("marketingObjectives").forEachObject { o ->
                db.insertWithOnConflict("objectives", null, contentValues {
                    put("id", o.optString("id", UUID.randomUUID().toString()))
                    put("description", o.optString("description"))
                    put("targetValue", o.optDoubleSafe("targetValue"))
                    put("type", o.optString("type"))
                    put("timeframe", o.optString("timeframe"))
                    put("createdAt", o.optString("createdAt"))
                    put("status", o.optString("status", "active"))
                }, SQLiteDatabase.CONFLICT_REPLACE)
            }
            root.optJSONArray("socialPosts").forEachObject { o ->
                db.insertWithOnConflict("social_posts", null, contentValues {
                    put("id", o.optString("id", UUID.randomUUID().toString()))
                    put("platform", o.optString("platform"))
                    put("caption", o.optString("caption"))
                    put("hashtags", o.optJSONArray("suggestedHashtags")?.toString() ?: "[]")
                    putNullable("imagePrompt", o.optString("imagePrompt", null))
                    putNullable("videoPrompt", o.optString("videoPrompt", null))
                    put("status", o.optString("status", "draft"))
                    putNullable("scheduledDate", o.optString("scheduledDate", null))
                    putNullable("marketingObjectiveId", o.optString("marketingObjectiveId", null))
                }, SQLiteDatabase.CONFLICT_REPLACE)
            }
            root.optJSONObject("brandManual")?.let { importBrand(db, parseBrand(it)) }
            root.optJSONObject("businessAnalysis")?.let { setBusinessAnalysisInternal(db, parseBusinessAnalysis(it)) }
            root.optJSONObject("marketingStrategy")?.let { setMarketingStrategyInternal(db, parseMarketingStrategy(it)) }
            root.optJSONArray("usageHistory").forEachObject { o ->
                db.insertWithOnConflict("usage_history", null, contentValues {
                    put("id", o.optString("id", UUID.randomUUID().toString()))
                    put("description", o.optString("description"))
                    put("model", o.optString("model"))
                    put("inputTokens", o.optInt("inputTokens"))
                    put("outputTokens", o.optInt("outputTokens"))
                    put("cost", o.optDoubleSafe("cost"))
                    put("type", o.optString("type"))
                    put("timestamp", o.optString("timestamp"))
                }, SQLiteDatabase.CONFLICT_REPLACE)
            }
    }

    private fun JSONArray?.forEachObject(block: (JSONObject) -> Unit) {
        if (this == null) return
        for (i in 0 until length()) block(getJSONObject(i))
    }

    private fun JSONArray?.insertCategoriesInto(db: SQLiteDatabase, table: String) = forEachObject { o ->
        db.insertWithOnConflict(table, null, contentValues {
            put("id", o.optString("id", UUID.randomUUID().toString()))
            put("name", o.optString("name"))
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun contentValues(block: ContentValues.() -> Unit): ContentValues = ContentValues().apply(block)
    private fun ContentValues.putNullable(key: String, value: String?) { if (value == null) putNull(key) else put(key, value) }

    private fun parseProduct(o: JSONObject): Product {
        val history = mutableListOf<PriceHistory>()
        o.optJSONArray("priceHistory").forEachObject { h ->
            history += PriceHistory(
                date = h.optString("date"),
                pricePerUnit = h.optDoubleSafe("pricePerUnit"),
                priceWithVat = h.optDoubleSafe("priceWithVat"),
                pricePerServing = h.optDoubleSafe("pricePerServing")
            )
        }
        val cost = o.optDoubleSafe("cost")
        val discount = o.optDoubleSafe("discount")
        val unit = o.optDoubleSafe("unitPrice", cost * (1.0 - discount / 100.0))
        return Product(
            id = o.optString("id", UUID.randomUUID().toString()),
            description = o.optString("description"),
            cost = cost,
            discount = discount,
            vat = o.optDoubleSafe("vat", 10.0),
            unitPrice = unit,
            servingsPerUnit = o.optDoubleSafe("servingsPerUnit", 1.0),
            sellingPrice = o.optDoubleSafe("sellingPrice"),
            profitAmount = o.optDoubleSafe("profitAmount"),
            profitMargin = o.optDoubleSafe("profitMargin"),
            category = o.optString("category", "Sin Categoría"),
            supplierCategory = o.optString("supplierCategory", "Sin Categoría de Proveedor"),
            supplierId = o.optString("supplierId", null),
            priceHistory = history
        )
    }

    private fun parseRecipe(o: JSONObject): Recipe {
        fun products(key: String): List<RecipeProduct> = buildList {
            o.optJSONArray(key).forEachObject { x -> add(RecipeProduct(x.optString("productId"), x.optDoubleSafe("quantity", 1.0))) }
        }
        val groups = buildList {
            o.optJSONArray("dynamicProductGroups").forEachObject { x -> add(DynamicProductGroup(x.optString("categoryId"), x.optDoubleSafe("quantity", 1.0))) }
        }
        val selections = mutableMapOf<String, String>()
        o.optJSONObject("defaultSelections")?.let { obj -> obj.keys().forEach { key -> selections[key] = obj.optString(key) } }
        val suggestion = o.optJSONObject("salesSuggestion")?.let { x ->
            SalesSuggestion(x.optString("menuDescription"), x.stringList("upsellSuggestions"), x.stringList("crossSellSuggestions"), x.optString("salesScript"))
        }
        return Recipe(
            id = o.optString("id", UUID.randomUUID().toString()),
            description = o.optString("description"),
            sellingPrice = o.optDoubleSafe("sellingPrice"),
            category = o.optString("category", "Otros"),
            type = o.optString("type", "simple"),
            products = products("products"),
            fixedProducts = products("fixedProducts"),
            dynamicProductGroups = groups,
            defaultSelections = selections,
            salesSuggestion = suggestion
        )
    }

    private fun insertProduct(db: SQLiteDatabase, p: Product) {
        val historyJson = JSONArray(p.priceHistory.map {
            JSONObject().apply {
                put("date", it.date)
                put("pricePerUnit", it.pricePerUnit)
                put("priceWithVat", it.priceWithVat)
                put("pricePerServing", it.pricePerServing)
            }
        }).toString()
        db.insertWithOnConflict("products", null, contentValues {
            put("id", p.id); put("description", p.description); put("cost", p.cost); put("discount", p.discount)
            put("vat", p.vat); put("unitPrice", p.unitPrice); put("servings", p.servingsPerUnit)
            put("sellingPrice", p.sellingPrice); put("profitAmount", p.profitAmount); put("profitMargin", p.profitMargin)
            put("category", p.category); put("supplierCategory", p.supplierCategory); putNullable("supplierId", p.supplierId)
            put("history", historyJson)
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun insertRecipe(db: SQLiteDatabase, r: Recipe) {
        fun productsJson(list: List<RecipeProduct>) = JSONArray(list.map {
            JSONObject().apply { put("productId", it.productId); put("quantity", it.quantity) }
        }).toString()
        val groups = JSONArray(r.dynamicProductGroups.map {
            JSONObject().apply { put("categoryId", it.categoryId); put("quantity", it.quantity) }
        }).toString()
        db.insertWithOnConflict("recipes", null, contentValues {
            put("id", r.id); put("description", r.description); put("sellingPrice", r.sellingPrice)
            put("category", r.category); put("type", r.type); put("products", productsJson(r.products))
            put("fixedProducts", productsJson(r.fixedProducts)); put("dynamicGroups", groups)
            put("defaultSelections", JSONObject(r.defaultSelections).toString())
            putNullable("salesSuggestion", r.salesSuggestion?.let(::salesSuggestionJson)?.toString())
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun importBrand(db: SQLiteDatabase, m: BrandManual) {
        db.insertWithOnConflict("brand_manual", null, contentValues {
            put("id", m.id); put("fileName", m.fileName); put("content", m.content); put("uploadedAt", m.uploadedAt)
            putNullable("toneOfVoice", m.toneOfVoice); putNullable("targetAudience", m.targetAudience); putNullable("visualIdentity", m.visualIdentity)
            put("brandPillars", JSONArray(m.brandPillars).toString())
        }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun parseBrand(o: JSONObject) = BrandManual(
        o.optString("id", UUID.randomUUID().toString()), o.optString("fileName"), o.optString("content"), o.optString("uploadedAt"),
        o.optString("toneOfVoice", null), o.optString("targetAudience", null), o.optString("visualIdentity", null), o.stringList("brandPillars")
    )

    private fun parseBusinessAnalysis(o: JSONObject) = BusinessAnalysis(
        o.optString("businessType"), o.optString("targetAudience"), o.optString("brandConcept"), o.stringList("strengths"),
        o.stringList("improvementAreas"), o.stringList("opportunities"), o.optString("pricingStrategy"),
        o.stringList("strategicRecommendations"), o.stringList("operationalEfficiency"), o.optString("marketPositioning")
    )

    private fun parseMarketingStrategy(o: JSONObject) = MarketingStrategy(
        o.stringList("promotionalEngineering"), o.stringList("dynamicMenuOptimization"), o.stringList("revenueManagement"),
        o.stringList("suggestedActionPlan"), o.stringList("seasonalityInsights")
    )

    private fun setBusinessAnalysisInternal(db: SQLiteDatabase, x: BusinessAnalysis) {
        db.insertWithOnConflict("business_analysis", null, contentValues { put("id", 1); put("payload", businessJson(x).toString()) }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    private fun setMarketingStrategyInternal(db: SQLiteDatabase, x: MarketingStrategy) {
        db.insertWithOnConflict("marketing_strategy", null, contentValues { put("id", 1); put("payload", marketingJson(x).toString()) }, SQLiteDatabase.CONFLICT_REPLACE)
    }

    fun count(table: String): Int = dbRead("SELECT COUNT(*) FROM $table").use { if (it.moveToFirst()) it.getInt(0) else 0 }
    private fun dbRead(sql: String, args: Array<String>? = null) = readableDatabase.rawQuery(sql, args)

    fun getProducts(search: String = ""): List<Product> {
        val n = normalize(search)
        val sql = if (n.isBlank()) "SELECT * FROM products ORDER BY description" else "SELECT * FROM products WHERE LOWER(description) LIKE ? ORDER BY description"
        val c = dbRead(sql, if (n.isBlank()) null else arrayOf("%$n%"))
        return buildList { c.use { while (it.moveToNext()) add(productFrom(it)) } }
    }

    fun getProduct(id: String): Product? = dbRead("SELECT * FROM products WHERE id=?", arrayOf(id)).use { if (it.moveToFirst()) productFrom(it) else null }
    fun upsertProduct(p: Product) = insertProduct(writableDatabase, p)
    fun deleteProduct(id: String) { writableDatabase.delete("products", "id=?", arrayOf(id)) }

    private fun productFrom(c: Cursor): Product {
        val history = mutableListOf<PriceHistory>()
        val rawHistory = c.getString(c.getColumnIndexOrThrow("history")) ?: "[]"
        JSONArray(rawHistory).forEachObject { h -> history += PriceHistory(h.optString("date"), h.optDoubleSafe("pricePerUnit"), h.optDoubleSafe("priceWithVat"), h.optDoubleSafe("pricePerServing")) }
        return Product(
            id = c.getString(c.getColumnIndexOrThrow("id")), description = c.getString(c.getColumnIndexOrThrow("description")),
            cost = c.getDouble(c.getColumnIndexOrThrow("cost")), discount = c.getDouble(c.getColumnIndexOrThrow("discount")),
            vat = c.getDouble(c.getColumnIndexOrThrow("vat")), unitPrice = c.getDouble(c.getColumnIndexOrThrow("unitPrice")),
            servingsPerUnit = c.getDouble(c.getColumnIndexOrThrow("servings")), sellingPrice = c.getDouble(c.getColumnIndexOrThrow("sellingPrice")),
            profitAmount = c.getDouble(c.getColumnIndexOrThrow("profitAmount")), profitMargin = c.getDouble(c.getColumnIndexOrThrow("profitMargin")),
            category = c.getString(c.getColumnIndexOrThrow("category")) ?: "Sin Categoría",
            supplierCategory = c.getString(c.getColumnIndexOrThrow("supplierCategory")) ?: "Sin Categoría de Proveedor",
            supplierId = c.getString(c.getColumnIndexOrThrow("supplierId")), priceHistory = history
        )
    }

    fun getSuppliers(): List<Supplier> = dbRead("SELECT * FROM suppliers ORDER BY name").use { c ->
        buildList { while (c.moveToNext()) add(Supplier(c.getString(0), c.getString(1), c.getString(2) ?: "", c.getString(3))) }
    }
    fun upsertSupplier(s: Supplier) { writableDatabase.insertWithOnConflict("suppliers", null, contentValues { put("id",s.id); put("name",s.name); put("description",s.description); putNullable("phone",s.phone) }, SQLiteDatabase.CONFLICT_REPLACE) }
    fun deleteSupplier(id: String) { writableDatabase.delete("suppliers", "id=?", arrayOf(id)) }

    fun getCategories(): List<Category> = dbRead("SELECT id,name FROM categories ORDER BY name").use { c -> buildList { while (c.moveToNext()) add(Category(c.getString(0), c.getString(1))) } }
    fun getRecipeCategories(): List<Category> = dbRead("SELECT id,name FROM recipe_categories ORDER BY name").use { c -> buildList { while (c.moveToNext()) add(Category(c.getString(0), c.getString(1))) } }
    fun getSupplierCategories(): List<Category> = dbRead("SELECT id,name,supplierId FROM supplier_categories ORDER BY name").use { c -> buildList { while (c.moveToNext()) add(Category(c.getString(0), c.getString(1), c.getString(2))) } }

    fun addCategory(type: String, name: String, supplierId: String? = null): Category {
        val clean = name.trim()
        require(clean.isNotBlank()) { "El nombre no puede estar vacío." }
        val id = UUID.randomUUID().toString()
        when (type) {
            "product" -> writableDatabase.insert("categories", null, contentValues { put("id", id); put("name", clean) })
            "recipe" -> writableDatabase.insert("recipe_categories", null, contentValues { put("id", id); put("name", clean) })
            "supplier" -> writableDatabase.insert("supplier_categories", null, contentValues { put("id", id); put("name", clean); putNullable("supplierId", supplierId) })
            else -> error("Tipo de categoría no válido")
        }
        return Category(id, clean, supplierId)
    }

    fun renameCategory(category: Category, type: String, newName: String) {
        val clean = newName.trim()
        require(clean.isNotBlank()) { "El nombre no puede estar vacío." }
        writableDatabase.beginTransaction()
        try {
            when (type) {
                "product" -> {
                    writableDatabase.update("categories", contentValues { put("name", clean) }, "id=?", arrayOf(category.id))
                    writableDatabase.update("products", contentValues { put("category", clean) }, "category=?", arrayOf(category.name))
                }
                "recipe" -> {
                    writableDatabase.update("recipe_categories", contentValues { put("name", clean) }, "id=?", arrayOf(category.id))
                    writableDatabase.update("recipes", contentValues { put("category", clean) }, "category=?", arrayOf(category.name))
                }
                "supplier" -> {
                    writableDatabase.update("supplier_categories", contentValues { put("name", clean) }, "id=?", arrayOf(category.id))
                    if (category.supplierId.isNullOrBlank()) {
                        writableDatabase.update("products", contentValues { put("supplierCategory", clean) }, "supplierCategory=?", arrayOf(category.name))
                    } else {
                        writableDatabase.update("products", contentValues { put("supplierCategory", clean) }, "supplierCategory=? AND supplierId=?", arrayOf(category.name, category.supplierId))
                    }
                }
                else -> error("Tipo de categoría no válido")
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }

    fun deleteCategory(category: Category, type: String) {
        writableDatabase.beginTransaction()
        try {
            when (type) {
                "product" -> {
                    writableDatabase.delete("categories", "id=?", arrayOf(category.id))
                    writableDatabase.update("products", contentValues { put("category", "Sin Categoría") }, "category=?", arrayOf(category.name))
                }
                "recipe" -> {
                    writableDatabase.delete("recipe_categories", "id=?", arrayOf(category.id))
                    writableDatabase.update("recipes", contentValues { put("category", "Otros") }, "category=?", arrayOf(category.name))
                }
                "supplier" -> {
                    writableDatabase.delete("supplier_categories", "id=?", arrayOf(category.id))
                    val where = if (category.supplierId.isNullOrBlank()) "supplierCategory=?" else "supplierCategory=? AND supplierId=?"
                    val args = if (category.supplierId.isNullOrBlank()) arrayOf(category.name) else arrayOf(category.name, category.supplierId)
                    writableDatabase.update("products", contentValues { put("supplierCategory", "Sin Categoría de Proveedor") }, where, args)
                }
                else -> error("Tipo de categoría no válido")
            }
            writableDatabase.setTransactionSuccessful()
        } finally { writableDatabase.endTransaction() }
    }

    fun getProductsForCategory(category: Category): List<Product> = getProducts().filter { ParsingUtils.normalize(it.category) == ParsingUtils.normalize(category.name) }
    fun getRecipesForCategory(category: Category): List<Recipe> = getRecipes().filter { ParsingUtils.normalize(it.category) == ParsingUtils.normalize(category.name) }
    fun getProductsForSupplierCategory(supplier: Supplier, category: Category): List<Product> = getProducts().filter {
        it.supplierId == supplier.id && ParsingUtils.normalize(it.supplierCategory) == ParsingUtils.normalize(category.name)
    }

    fun getRecipes(search: String = ""): List<Recipe> {
        val n = normalize(search)
        val sql = if (n.isBlank()) "SELECT * FROM recipes ORDER BY description" else "SELECT * FROM recipes WHERE LOWER(description) LIKE ? ORDER BY description"
        val c = dbRead(sql, if (n.isBlank()) null else arrayOf("%$n%"))
        return buildList { c.use { while (it.moveToNext()) add(recipeFrom(it)) } }
    }
    private fun recipeFrom(c: Cursor): Recipe {
        fun products(key: String): List<RecipeProduct> = buildList {
            JSONArray(c.getString(c.getColumnIndexOrThrow(key)) ?: "[]").forEachObject { x ->
                add(RecipeProduct(x.optString("productId"), x.optDoubleSafe("quantity", 1.0)))
            }
        }
        val groups = buildList {
            JSONArray(c.getString(c.getColumnIndexOrThrow("dynamicGroups")) ?: "[]").forEachObject { x ->
                add(DynamicProductGroup(x.optString("categoryId"), x.optDoubleSafe("quantity", 1.0)))
            }
        }
        val selections = mutableMapOf<String, String>()
        val ds = JSONObject(c.getString(c.getColumnIndexOrThrow("defaultSelections")) ?: "{}")
        ds.keys().forEach { k -> selections[k] = ds.optString(k) }
        val suggestion = c.getString(c.getColumnIndexOrThrow("salesSuggestion"))?.let { raw ->
            runCatching { parseSalesSuggestion(JSONObject(raw)) }.getOrNull()
        }
        return Recipe(
            id = c.getString(c.getColumnIndexOrThrow("id")),
            description = c.getString(c.getColumnIndexOrThrow("description")),
            sellingPrice = c.getDouble(c.getColumnIndexOrThrow("sellingPrice")),
            category = c.getString(c.getColumnIndexOrThrow("category")) ?: "Otros",
            type = c.getString(c.getColumnIndexOrThrow("type")) ?: "simple",
            products = products("products"),
            fixedProducts = products("fixedProducts"),
            dynamicProductGroups = groups,
            defaultSelections = selections,
            salesSuggestion = suggestion
        )
    }
    fun upsertRecipe(r: Recipe) = insertRecipe(writableDatabase, r)
    fun deleteRecipe(id: String) { writableDatabase.delete("recipes", "id=?", arrayOf(id)) }

    fun getFixedCosts(): List<FixedCost> = dbRead("SELECT * FROM fixed_costs ORDER BY description").use { c -> buildList { while (c.moveToNext()) add(FixedCost(c.getString(0), c.getString(1) ?: "", c.getDouble(2), c.getString(3) ?: "other")) } }
    fun replaceFixedCosts(list: List<FixedCost>) { val db=writableDatabase;db.beginTransaction();try{db.delete("fixed_costs",null,null);list.forEach{x->db.insert("fixed_costs",null,contentValues{put("id",x.id);put("description",x.description);put("amount",x.amount);put("category",x.category)})};db.setTransactionSuccessful()}finally{db.endTransaction()} }
    fun getSales(): List<SaleEntry> = dbRead("SELECT productName,quantity,totalRevenue,date FROM sales ORDER BY date DESC").use { c -> buildList { while (c.moveToNext()) add(SaleEntry(c.getString(0),c.getDouble(1),c.getDouble(2),c.getString(3))) } }
    fun replaceSales(list: List<SaleEntry>) { val db=writableDatabase;db.beginTransaction();try{db.delete("sales",null,null);list.forEach{x->db.insert("sales",null,contentValues{put("productName",x.productName);put("quantity",x.quantity);put("totalRevenue",x.totalRevenue);put("date",x.date)})};db.setTransactionSuccessful()}finally{db.endTransaction()} }

    fun getObjectives(): List<MarketingObjective> = dbRead("SELECT * FROM objectives ORDER BY createdAt DESC").use { c -> buildList { while(c.moveToNext()) add(MarketingObjective(c.getString(0),c.getString(1),c.getDouble(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6))) } }
    fun upsertObjective(o: MarketingObjective) { writableDatabase.insertWithOnConflict("objectives",null,contentValues{put("id",o.id);put("description",o.description);put("targetValue",o.targetValue);put("type",o.type);put("timeframe",o.timeframe);put("createdAt",o.createdAt);put("status",o.status)},SQLiteDatabase.CONFLICT_REPLACE) }
    fun deleteObjective(id:String){writableDatabase.delete("objectives","id=?",arrayOf(id))}

    fun getPosts():List<SocialPost> = dbRead("SELECT * FROM social_posts ORDER BY scheduledDate").use{c->buildList{while(c.moveToNext()){val tags=JSONArray(c.getString(3) ?: "[]");add(SocialPost(c.getString(0),c.getString(1),c.getString(2),buildList{for(j in 0 until tags.length())add(tags.optString(j))},c.getString(4),c.getString(5),c.getString(6),c.getString(7),c.getString(8)))}}}
    fun upsertPost(p:SocialPost){writableDatabase.insertWithOnConflict("social_posts",null,contentValues{put("id",p.id);put("platform",p.platform);put("caption",p.caption);put("hashtags",JSONArray(p.hashtags).toString());putNullable("imagePrompt",p.imagePrompt);putNullable("videoPrompt",p.videoPrompt);put("status",p.status);putNullable("scheduledDate",p.scheduledDate);putNullable("marketingObjectiveId",p.marketingObjectiveId)},SQLiteDatabase.CONFLICT_REPLACE)}
    fun deletePost(id:String){writableDatabase.delete("social_posts","id=?",arrayOf(id))}

    fun getBrandManual():BrandManual?=dbRead("SELECT * FROM brand_manual LIMIT 1").use{c->if(c.moveToFirst()){val arr=JSONArray(c.getString(7) ?: "[]");BrandManual(c.getString(0),c.getString(1),c.getString(2),c.getString(3),c.getString(4),c.getString(5),c.getString(6),buildList{for(i in 0 until arr.length())add(arr.optString(i))})}else null}
    fun upsertBrandManual(m:BrandManual)=importBrand(writableDatabase,m)
    fun getBusinessAnalysis():BusinessAnalysis?=dbRead("SELECT payload FROM business_analysis WHERE id=1").use{c->if(c.moveToFirst())parseBusinessAnalysis(JSONObject(c.getString(0)))else null}
    fun setBusinessAnalysis(x:BusinessAnalysis)=setBusinessAnalysisInternal(writableDatabase,x)
    fun getMarketingStrategy():MarketingStrategy?=dbRead("SELECT payload FROM marketing_strategy WHERE id=1").use{c->if(c.moveToFirst())parseMarketingStrategy(JSONObject(c.getString(0)))else null}
    fun setMarketingStrategy(x:MarketingStrategy)=setMarketingStrategyInternal(writableDatabase,x)

    fun addUsage(entry:UsageEntry){writableDatabase.insertWithOnConflict("usage_history",null,contentValues{put("id",entry.id);put("description",entry.description);put("model",entry.model);put("inputTokens",entry.inputTokens);put("outputTokens",entry.outputTokens);put("cost",entry.cost);put("type",entry.type);put("timestamp",entry.timestamp)},SQLiteDatabase.CONFLICT_REPLACE)}

    fun exportBackup(): String {
        val db = readableDatabase
        fun rows(table:String,keys:Array<String>):JSONArray=db.query(table,keys,null,null,null,null,null).use{c->JSONArray().also{while(c.moveToNext()){val o=JSONObject();for(i in keys.indices){when(c.getType(i)){Cursor.FIELD_TYPE_INTEGER->o.put(keys[i],c.getLong(i));Cursor.FIELD_TYPE_FLOAT->o.put(keys[i],c.getDouble(i));Cursor.FIELD_TYPE_NULL->o.put(keys[i],JSONObject.NULL);else->o.put(keys[i],c.getString(i))}};it.put(o)}}}
        val root=JSONObject().apply{
            put("app","gestion-soul");put("version","1.0-offline");put("exportedAt",Instant.now().toString())
            put("database",JSONObject().apply{
                put("products",JSONArray(getProducts().map(::productJson)))
                put("recipes",JSONArray(getRecipes().map(::recipeJson)))
                put("suppliers",rows("suppliers",arrayOf("id","name","description","phone")))
                put("categories",rows("categories",arrayOf("id","name")))
                put("recipeCategories",rows("recipe_categories",arrayOf("id","name")))
                put("supplierProductCategories",rows("supplier_categories",arrayOf("id","name","supplierId")))
                put("fixedCosts",rows("fixed_costs",arrayOf("id","description","amount","category")))
                put("salesHistory",rows("sales",arrayOf("productName","quantity","totalRevenue","date")))
                put("marketingObjectives",rows("objectives",arrayOf("id","description","targetValue","type","timeframe","createdAt","status")))
                put("socialPosts",JSONArray(getPosts().map(::postJson)))
                getBrandManual()?.let{put("brandManual",brandJson(it))}
                getBusinessAnalysis()?.let{put("businessAnalysis",businessJson(it))}
                getMarketingStrategy()?.let{put("marketingStrategy",marketingJson(it))}
                put("usageHistory",rows("usage_history",arrayOf("id","description","model","inputTokens","outputTokens","cost","type","timestamp")))
            })
        }
        return root.toString(2)
    }

    private fun productJson(p:Product)=JSONObject().apply{put("unitPrice",p.unitPrice);put("discount",p.discount);put("description",p.description);put("profitMargin",p.profitMargin);put("category",p.category);put("cost",p.cost);putNullableJson("supplierId",p.supplierId);put("priceHistory",JSONArray(p.priceHistory.map{JSONObject().apply{put("pricePerUnit",it.pricePerUnit);put("date",it.date);put("priceWithVat",it.priceWithVat);put("pricePerServing",it.pricePerServing)}}));put("sellingPrice",p.sellingPrice);put("servingsPerUnit",p.servingsPerUnit);put("profitAmount",p.profitAmount);put("vat",p.vat);put("supplierCategory",p.supplierCategory);put("id",p.id)}
    private fun recipeJson(r:Recipe)=JSONObject().apply{put("description",r.description);put("type",r.type);put("products",JSONArray(r.products.map{JSONObject().apply{put("productId",it.productId);put("quantity",it.quantity)}}));put("sellingPrice",r.sellingPrice);put("category",r.category);put("id",r.id);put("fixedProducts",JSONArray(r.fixedProducts.map{JSONObject().apply{put("productId",it.productId);put("quantity",it.quantity)}}));put("dynamicProductGroups",JSONArray(r.dynamicProductGroups.map{JSONObject().apply{put("categoryId",it.categoryId);put("quantity",it.quantity)}}));put("defaultSelections",JSONObject(r.defaultSelections));r.salesSuggestion?.let{put("salesSuggestion",salesSuggestionJson(it))}}
    private fun salesSuggestionJson(x:SalesSuggestion)=JSONObject().apply{put("menuDescription",x.menuDescription);put("upsellSuggestions",JSONArray(x.upsellSuggestions));put("crossSellSuggestions",JSONArray(x.crossSellSuggestions));put("salesScript",x.salesScript)}
    private fun parseSalesSuggestion(x:JSONObject)=SalesSuggestion(x.optString("menuDescription"),x.stringList("upsellSuggestions"),x.stringList("crossSellSuggestions"),x.optString("salesScript"))
    private fun postJson(p:SocialPost)=JSONObject().apply{put("status",p.status);putNullableJson("videoPrompt",p.videoPrompt);put("id",p.id);putNullableJson("scheduledDate",p.scheduledDate);putNullableJson("marketingObjectiveId",p.marketingObjectiveId);putNullableJson("imagePrompt",p.imagePrompt);put("platform",p.platform);put("suggestedHashtags",JSONArray(p.hashtags));put("caption",p.caption)}
    private fun brandJson(m:BrandManual)=JSONObject().apply{put("id",m.id);put("fileName",m.fileName);put("content",m.content);put("uploadedAt",m.uploadedAt);putNullableJson("toneOfVoice",m.toneOfVoice);putNullableJson("targetAudience",m.targetAudience);putNullableJson("visualIdentity",m.visualIdentity);put("brandPillars",JSONArray(m.brandPillars))}
    private fun businessJson(x:BusinessAnalysis)=JSONObject().apply{put("businessType",x.businessType);put("targetAudience",x.targetAudience);put("brandConcept",x.brandConcept);put("strengths",JSONArray(x.strengths));put("improvementAreas",JSONArray(x.improvementAreas));put("opportunities",JSONArray(x.opportunities));put("pricingStrategy",x.pricingStrategy);put("strategicRecommendations",JSONArray(x.strategicRecommendations));put("operationalEfficiency",JSONArray(x.operationalEfficiency));put("marketPositioning",x.marketPositioning)}
    private fun marketingJson(x:MarketingStrategy)=JSONObject().apply{put("promotionalEngineering",JSONArray(x.promotionalEngineering));put("dynamicMenuOptimization",JSONArray(x.dynamicMenuOptimization));put("revenueManagement",JSONArray(x.revenueManagement));put("suggestedActionPlan",JSONArray(x.suggestedActionPlan));put("seasonalityInsights",JSONArray(x.seasonalityInsights))}
    private fun JSONObject.putNullableJson(key:String,value:String?){put(key,value ?: JSONObject.NULL)}

    private fun normalize(s:String):String=ParsingUtils.normalize(s)
}
