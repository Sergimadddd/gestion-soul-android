# Gestión Soul: no app-specific shrinking rules required for the current build.
