# Gestión Soul — Android Offline

Reconstrucción nativa de la aplicación web original de Gestión Soul para Android.

## Qué contiene

- Kotlin + Jetpack Compose.
- SQLite local mediante SQLiteOpenHelper, sin Firebase.
- Datos iniciales reales del backup adjunto.
- OCR de facturas/carta con ML Kit bundled.
- IA local mediante Gemini Nano/Prompt API cuando el dispositivo lo admite.
- Fallback local determinista para mantener la aplicación operativa sin API.
- Proveedor remoto opcional compatible con endpoints OpenAI-compatible.
- Importación/exportación de backup JSON.
- Importación local de CSV/XLS/XLSX y documentos de texto.
- Pedidos agrupados por proveedor y envío por WhatsApp.

## Datos migrados

El backup real importado en `app/src/main/assets/initial_backup.json` contiene:

- 141 productos
- 107 recetas
- 36 recetas dinámicas
- 13 proveedores
- 16 categorías de producto
- 12 categorías de receta
- 31 categorías de proveedor
- 397 registros de ventas
- 1 objetivo de marketing
- 5 publicaciones sociales
- 90 registros de uso de IA
- 0 costes fijos

## IA y privacidad

El modo por defecto es local. No se requiere una API key para utilizar la gestión normal de la aplicación. La función generativa local avanzada usa Gemini Nano/Prompt API solo cuando AICore del dispositivo la soporta; si no, se activa un fallback local sin red. La API remota es opcional y se configura desde Ajustes.

Las API keys remotas se almacenan cifradas con Android Keystore.

## Build local

Requisitos:

- Android Studio compatible con AGP 9.4.
- JDK 17 o superior.
- Android SDK API 37.
- Android Build Tools 36.0.0 o una versión compatible con AGP 9.4.

Comandos:

```text
./gradlew :app:assembleDebug
./gradlew :app:assembleRelease
```

APK debug:

`app/build/outputs/apk/debug/app-debug.apk`

APK release sin firmar:

`app/build/outputs/apk/release/app-release-unsigned.apk`

## Nota de este entorno

Este paquete ha sido preparado y validado a nivel de fuentes, estructura, datos y configuración. La sesión donde se generó este paquete no dispone del Android SDK/Gradle descargado ni de acceso de red para resolver las dependencias, por lo que aquí no se ha podido producir honestamente una APK compilada. El workflow de GitHub Actions incluido permite realizar el build en un runner con Android SDK.
