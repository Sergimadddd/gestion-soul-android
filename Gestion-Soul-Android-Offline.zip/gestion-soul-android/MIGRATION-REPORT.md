# Informe de migración — Gestión Soul

## Fuente

- Aplicación original: `gestión-soul-1.0.zip`
- Backup real: `Base.de.datos.rar`
- Backup integrado: `backup_gestion_soul_2026-09-25_1347.json`

## Conteo validado del backup real

| Entidad | Registros |
|---|---:|
| Productos | 141 |
| Recetas | 107 |
| Recetas dinámicas | 36 |
| Proveedores | 13 |
| Categorías de producto | 16 |
| Categorías de receta | 12 |
| Categorías de proveedor | 31 |
| Costes fijos | 0 |
| Ventas | 397 |
| Objetivos de marketing | 1 |
| Publicaciones sociales | 5 |
| Historial de uso IA | 90 |
| Recetas con SalesSuggestion | 1 |

## Transformaciones

- Firebase/Firestore sustituido por SQLite local mediante una capa de base local.
- Estado de UI React sustituido por ViewModels + StateFlow.
- Modales React sustituidos por diálogos Compose.
- Matching de productos conserva normalización, Levenshtein y umbral 0.8.
- Cálculos de producto y receta migrados a Kotlin.
- Pedidos se mantienen localmente y se agrupan por proveedor.
- OCR se procesa en el dispositivo con modelo bundled.
- La IA generativa se abstrae detrás de proveedor local/remoto.

## Limitación conocida

La IA local generativa avanzada depende de la disponibilidad de Gemini Nano/AICore en el dispositivo. Cuando no está disponible, la aplicación no realiza una llamada de red automática: utiliza fallback local determinista.
